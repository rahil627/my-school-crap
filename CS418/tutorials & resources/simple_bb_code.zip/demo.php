<html>
	<head><title>BBcode Test</title></head>
	<body>
<?php
	if(!empty($_POST['test'])){
		$t = stripslashes($_POST['test']);
		require_once('simple_bb_code.php');
		$bb = new Simple_BB_Code();
		$res = $bb->parse($t);
		echo "<textarea cols=50 rows=20>$res</textarea><div style='border:1px solid red'>$res</div>";
	}
?>
	<form method="post" action="index.php">
	<textarea name="test" cols=50 rows=20><?php
			if(isset($t)){
				echo $t;
			}
		?>
	</textarea>
	<input type="submit" value="Test">
	</form>
	</body>
</html>