<?php
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005, Chris Cornutt	                                       |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+

class feedManage {

	function feedManage(){
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php");
		$this->digg=new diggManage();
	}

	//-------------------------
	function buildXML($data_array){
		$channel_data=array(
			"title"=>"diggClone","language"=>"en-us",
			"link"=>"http://www.talkingpixes.org/diggclone/index.php",
			"description"=>"diggClone"
		);
		$xml="";
		$xml.="<rss version=\"2.0\">\n";
		$xml.="<channel>";
		
		foreach($channel_data as $key => $value){
			$xml.=$this->displayItem($key,$value);
		}

		foreach($data_array as $key => $value){
			$xml.="<item>\n";
			foreach($value as $ikey => $ivalue){
				$xml.=$this->displayItem($ikey,$ivalue);
			}
			$xml.="</item>\n";
		}

		$xml.="</channel>\n";
		$xml.="</rss>";

		echo $xml;
	}

	function displayItem($key,$data){
		if($return=$this->filterOutput($key,$data)){
			return "<".$return['key'].">".str_replace("&","&amp;",$return['data'])."</".$return['key'].">\n";
		}
	}
	function filterOutput($key,$data){
		switch(strtoupper($key)){
			case "SUBMITTED_USER_ID": 
			case "CAT_TITLE":
			case "CAT_ID":
			case "VOTE_COUNT":
			case "COMMENT_COUNT":
			case "USERNAME":
			case "CATEGORY":
			case "URL":
				return false; break;
			//Mon, 8 Aug 2005 20:06:19 GMT
			case "DATE_POSTED":		$key="pubDate"; $data=date("r",$data); break;
			case "CONTENT":			$key="description"; break;
			case "ID":				$key="link"; $data="http://www.talkingpixels.org/diggclone/post_id=".$data; break;
		}
		return array("key"=>$key,"data"=>$data);
	}
}
?>