<?php
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005, Chris Cornutt	                                       |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+

class databaseManage {

	var $db_user="myname";
	var $db_pass="mypass";
	var $db_host="localhost";
	var $db_name="diggclone";

	function databaseManage(){
	}
	function query($type,$sql){
		//echo "SQL: ".$sql."<br/>\n";

		switch(strtolower($type)){
			case "send": $returned=$this->sendTo($sql); break;
			case "get": $returned=$this->fetchFrom($sql); break;
		}
		return $returned;
	}
	function connectTo(){
		$db=mysql_connect($this->db_host,$this->db_user,$this->db_pass);
		mysql_select_db($this->db_name,$db);
		return $db;
	}
	function sendTo($sql){
		$db=$this->connectTo();
		$query=mysql_query($sql) or die("error: ".mysql_error());
		$this->insert_id=mysql_insert_id();
		return true;
	}
	function fetchFrom($sql){
		$db=$this->connectTo();
		$query=mysql_query($sql) or die("error: ".mysql_error());
		while($rows=@mysql_fetch_assoc($query)){
			$returned[]=$rows;
		}
		return $returned;
	}

	//----------------------------------
	function buildInsert($table,$data){
		$keys=""; $values="";
		foreach($data as $key => $value){
			$keys.=$key.",";
			$values.="'".addslashes($value)."',";
		}
		$keys=substr($keys,0,strlen($keys)-1);
		$values=substr($values,0,strlen($values)-1);

		$sql="insert into ".$table." (".$keys.") values (".$values.")";
		return $sql;
	}
	function buildUpdate($table,$data,$where_clause=''){
		$update_string="";
		$sql="update ".$table ." set ";
		foreach($data as $key => $value){
			$update_string.=$key."='".addslashes($value)."',";
		}
		$update_string=substr($update_string,0,strlen($update_string)-1);
		$sql.=$update_string;
		if(!empty($where_clause)){ $sql.=" ".$where_clause; }
		//echo "SQL: ".$sql."</br>";
		return $sql;
	}
}

?>
