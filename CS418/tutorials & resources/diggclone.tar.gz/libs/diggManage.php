<?php
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005, Chris Cornutt	                                       |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+

class diggManage {

	var $promote_level		= "20";
	var $records_to_page	= "5";

	function diggManage(){
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/databaseManage.php");
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/userManage.php");
		$this->db		= new databaseManage();
		$this->user		= new userManage($this->db);
	}

	function getThisURL(){
		$this_url=$_SERVER['PHP_SELF']."?";
		if(isset($_GET['n'])){ $this_url.="n=".$_GET['n']."&"; }
		if(isset($_GET['s'])){ $this_url.="s=".$_GET['s']."&"; }
		$this_url=substr($this_url,0,strlen($this_url)-1);
	}

	function getStoryData($post_id='',$page='',$promoted='',$cat=''){
		$sql="select p.title,p.content,p.date_posted,p.category,p.url,p.submitted_user_id,p.ID,pc.cat_title,u.username,pc.ID as cat_id,count(distinct pv.ID) as vote_count, count(distinct pcom.ID) as comment_count from posts p, post_cats pc, users u left join post_votes pv on pv.post_id=p.ID left join post_comments pcom on pcom.post_id=p.ID where pc.ID=p.category and u.ID=p.submitted_user_id ";
		//$sql.="and pv.post_id=p.ID";
		if(!empty($post_id)){	$sql.=" and p.ID='".$post_id."'";	}
		if(!empty($cat)){		$sql.=" and p.category='".$cat."'"; }
		$sql.=" group by p.title,p.content,p.date_posted,p.category,p.url,p.submitted_user_id,p.ID,pc.cat_title,u.username ";
		if(!empty($promoted)){ 
			$sql.=($promoted=="1") ? " having vote_count>=".$this->promote_level : " having vote_count<".$this->promote_level;
		}
		$sql.=" order by p.date_posted desc";
		if($page!="0"){ $page--; $sql.=" LIMIT ".($page*5).",5"; }

		//echo "SQL: ".$sql."<br/>";
		$results=$this->db->query("get",$sql);
		return $results;
	}
	function getAllStoryCount($type=''){
		if(!empty($type)){
			switch(strtolower($type)){
				case "all": 
					$sql="select count(ID) as story_count from posts";
					break;
				case "promoted": 
					break;
				case "pending": 
					break;
			}
		}else{
			$sql="select count(ID) as story_count from posts";
		}
		$results=$this->db->query("get",$sql);
		return $results[0]['story_count'];
	}

	//-----------------------------
	function insertStory($data_array){
		$sql=$this->db->buildInsert("posts",$data_array);
		//echo "SQL: ".$sql."<br/>";
		$this->db->query("send",$sql);
	}
	function updateStory($data_array){
		//echo "<pre>"; print_r($data_array); echo "</pre>";

		$where=" where ID='".$data_array['post_id']."'";
		unset($data_array['post_id'],$data_array['username']);
		$sql=$this->db->buildUpdate("posts",$data_array,$where); //echo "SQL: ".$sql."<br/>";
		$this->db->query("send",$sql);
	}
	function deleteStory($post_id){
		$sql="delete from posts where ID='".$post_id."'";
		//echo "SQL: ".$sql."<br/>";
		$this->db->query("send",$sql);
	}

	//-----------------------------
	function getComments($post_id){
		$sql="select title,content,user_id,post_id,date_posted,ID from post_comments where post_id='".$post_id."'";
		return $this->db->query("get",$sql);
	}
	function postComment($data){
		$sql=$this->db->buildInsert("post_comments",$data);
		//echo "SQL: ".$sql."<br/>";
		$this->db->query("send",$sql);
	}

	//-----------------------------
	function getPostCatData($cat_id=''){
		$sql="select cat_title, cat_desc, ID from post_cats order by cat_title asc";
		if(!empty($cat_id)){ $sql.=" where ID='".$cat_id."'"; }
		return $this->db->query("get",$sql);
	}
	function updatePostCatData($data,$id){
		$sql=$this->db->buildUpdate("post_cats",$data,"where ID='".$id."'");
		//echo "SQL: ".$sql."<br/>";
		return $this->db->query("get",$sql);
	}
	function insertPostCatData($data){
		$sql=$this->db->buildInsert("post_cats",$_POST);
		//echo "SQL: ".$sql."<br/>";
		return $this->db->query("get",$sql);
	}
	function deletePostCatData($cat_id){
		$sql="delete from post_cats where ID='".$cat_id."'";
		return $this->db->query("get",$sql);
	}

	//-----------------------------
	function addVote($post_id,$user_id){
		$sql="insert into post_votes (post_id,user_id,date_voted,ID) values ('".$post_id."','".$user_id."','".time()."',NULL)";
		$this->db->query("send",$sql);
	}
	function getVotes($post_id){
		$sql="select count(user_id) as vote_count from post_votes where post_id='".$post_id."'";
		$results=$this->db->query("get",$sql); //print_r($results);
		return $results[0]['vote_count'];
	}
	function getPostVoters($post_id){
		$sql="select distinct u.ID,u.username from post_votes pv, users u where pv.post_id='".$post_id."' and pv.user_id=u.ID";
		$results=$this->db->query("get",$sql); //print_r($results);
		return $results;
	}
	function checkVotesUser($post_id,$user_id){
		$sql="select count(user_id) as vote_count from post_votes where user_id='".$user_id."' and post_id='".$post_id."'";
		$results=$this->db->query("get",$sql);
		if($results[0]['vote_count']>0){ return true; }else{ return false; }
	}
	function getTopVoters(){
		$sql="select count(pv.ID) as vote_count,pv.user_id,u.username from post_votes pv,users u where u.ID=pv.user_id group by pv.user_id order by vote_count desc";
		return $this->db->query("get",$sql);
	}
	function getLatestVotes(){
		$sql="select distinct p.ID, pv.post_id,p.title,p.date_posted,p.content,p.category,p.url,p.submitted_user_id,pc.cat_title,u.username,pv.date_voted,pc.ID as cat_id,count(distinct pv.ID) as vote_count, count(distinct pcom.ID) as comment_count from posts p, post_cats pc, users u left join post_votes pv on pv.post_id=p.ID left join post_comments pcom on pcom.post_id=p.ID where pc.ID=p.category and u.ID=p.submitted_user_id and pv.date_voted is not null";
		$sql.=" group by pv.post_id,p.title,p.date_posted,p.content,p.category,p.url,p.submitted_user_id,p.ID,pc.cat_title,u.username ";
		$sql.=" order by pv.date_voted desc";

		return $this->db->query("get",$sql);
	}

	//-----------------------------
	function getCategoryData($promoted=''){
		$sql="select pc.cat_title,pc.cat_desc,pc.ID,count(p.ID) as post_count from post_cats pc left join posts p on pc.ID=p.category group by pc.cat_title,pc.cat_desc,pc.ID order by pc.cat_title asc limit 50";
		return $this->db->query("get",$sql);
	}
	function getCategoryInfo($id=''){
		$sql="select cat_title, cat_desc, ID from post_cats";
		if(!empty($id)){ $sql.=" where ID='".$id."'"; }
		return $this->db->query("get",$sql);
	}

	//-----------------------------
	function searchPosts($term){
		$sql="select p.title,p.content,p.date_posted,p.category,p.url,p.submitted_user_id,p.ID,pc.cat_title,u.username,pc.ID as cat_id,count(distinct pv.ID) as vote_count, count(distinct pcom.ID) as comment_count from posts p, post_cats pc, users u left join post_votes pv on pv.post_id=p.ID left join post_comments pcom on pcom.post_id=p.ID where pc.ID=p.category and u.ID=p.submitted_user_id ";
		$sql.=" and (upper(p.title) like '%".strtoupper($term)."%' or upper(p.content) like '%".strtoupper($term)."%')";
		$sql.=" group by p.title,p.content,p.date_posted,p.category,p.url,p.submitted_user_id,p.ID,pc.cat_title,u.username ";
		$sql.=" order by p.date_posted desc";

		//echo "SQL: ".$sql."<br/><br/>";
		return $this->db->query("get",$sql);
	}

	function buildFeedURL(){
		$curr_page=$_SERVER['REQUEST_URI'];
		$link="feed.php?";

		//echo $curr_page."<br/>";
		if(!stristr($curr_page,"cast_votes") && stristr($curr_page,"index.php")){ $link.="promoted=1"; }
		if(isset($_GET['cat_id'])){ $link.="&cat=".$_GET['cat_id']; }

		return $link;
	}

	//-----------------------------
	function getUserPosts($user_id){
		$sql="select p.title,p.date_posted,p.ID,count(distinct pv.ID) as vote_count from posts p left join post_votes pv on pv.post_id=p.ID where p.submitted_user_id='".$user_id."' group by p.title,p.date_posted,p.ID order by p.date_posted desc";
		return $this->db->query("get",$sql);
	}
	function getUserComments($user_id){
		$sql="select pc.post_id,pc.ID,pc.date_posted,pc.content,p.title from post_comments pc, posts p where pc.user_id='".$user_id."' and pc.post_id=p.ID";
		return $this->db->query("get",$sql);
	}
}

?>