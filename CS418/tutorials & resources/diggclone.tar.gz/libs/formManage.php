<?php
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005, Chris Cornutt	                                       |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+

class formManage {

	var $submit_text		= "Submit";
	var $submit_image_path	= "";
	var $form_name			= "quickForm";
	var $form_table_name	= "quickForm_table";
	var $form_action		= "";
	var $errored_fields		= array();
	var $required_msgs		= array();
	var $required_fields	= array();
	var $states_array		= array(
			"AL"=>"Alabama","AR"=>"Arkansas","AZ"=>"Arizona","CA"=>"California","CO"=>"Colorado",
			"CT"=>"Connecticut","DC"=>"District of Columbia","DE"=>"Deleware","FL"=>"Florida",
			"GA"=>"Georgia","IA"=>"Iowa","ID"=>"Indiana","IL"=>"Illinois","IN"=>"Indiana",
			"KS"=>"Kansas","KY"=>"Kentucky","LA"=>"Louisiana","MA"=>"Massachusetts",
			"MD"=>"Maryland","ME"=>"Maine","MI"=>"Michigan","MN"=>"Minnesota","MO"=>"Missouri",
			"MS"=>"Mississippi","MT"=>"Montana","NC"=>"North Carolina","ND"=>"North Dakota",
			"NE"=>"Nebraska","NH"=>"New Hampshire","NM"=>"New Mexico","NJ"=>"New Jersey","NV"=>"Nevada",
			"NY"=>"New York","OH"=>"Ohio","OK"=>"Oklahoma","OR"=>"Oregon","PA"=>"Pennsylvania",
			"RI"=>"Rhode Island","SC"=>"South Carolina","SD"=>"South Dakota","TN"=>"Tennessee",
			"TX"=>"Texas","UT"=>"Utah","VA"=>"Virginia","VT"=>"Vermont","WA"=>"Washington",
			"WI"=>"Wisconsin","WV"=>"West Virginia","WY"=>"Wyoming"," "
		);
	var $countries_array=array(	
			"Algeria","Argentina","Australia","Austria","Bangladesh","Belgium","Bosnia and Herzegovina",
			"Brazil","Bulgaria","Canada","Chile","China","Colombia","Costa Rica","Denmark","Egypt","Finland",
			"France","Germany","Guatemala","Hungary","India","Indonesia","Iran","Ireland","Israel","Italy",
			"Japan","Jordan","Kenya","Korea, South","Kuwait","Malaysia","Mexico","Netherlands","New Zealand",
			"Norway","Oman","Pakistan","Paraguay","Peru","Philippines","Poland","Portugal","Qatar","Romania",
			"Russia","Saudi Arabia","Singapore","Slovenia","South Africa","Spain","Suriname","Sweden","Thailand",
			"Tunisia","Turkey","Ukraine","United Arab Emirates","United Kingdom","United States","Venezuela",
			"Vietnam","Yemen","Yugoslavia"
		);

	function formManage(){
	}
	
	//----------------------------------------
	//the user-defined form should replace these functions
	function form_body(){	 echo "form body: replace me!"; }
	function form_exec(){	 echo "form exec: replace me!"; }
	function form_prepare(){ echo "form prepare: replace me!"; }
	//----------------------------------------

	//----------------------------------------
	// General functions
	function displayError($error_text){
		echo "<tr>";
		echo "<td>&nbsp;</td>";
		echo "<td class=\"display_error\"><b>Note:</b> ".$error_text."</td>";
		echo "</tr>\n";
	}
	function displayRequired($field_name){
		if($this->isRequired($field_name)){
			return " <span style=\"color:#CA0005\">*</span>";
		}
	}
	function validate($field_name,$error_msg){
		$this->required_fields[]=$field_name; 
		$this->required_msgs[$field_name]=$error_msg;
	}
	function isRequired($field_name){
		if(in_array($field_name,$this->required_fields)){
			return true;
		}else{ return false; }
	}
	function getVal($field_name){
		if(isset($_POST[$field_name])){ return $_POST[$field_name]; }else{ return false; }
	}
	function setVal($field_name,$value){
		if(!isset($_POST[$this->submit_text])){ $_POST[$field_name]=$value; }
	}
	function setErrorMsg($field,$msg){
		$this->required_msgs[$field]=$msg;
	}
	function displayResultTable($msg,$stat='ok'){
		$img=($stat=='ok') ? "red_check.gif" : "red_check.gif";
		?>
		<br/><br/>
		<center>
		<table cellpadding="0" cellspacing="0" border="0" width="500">
		<tr>
			<td><img src="/img/<?=$img?>"></td>
			<td class="result_message">
				<b>Result:</b><br/>
				<?=$msg?>
			</td>
		</tr>
		</table>
		</center>
		<?php
	}
	//----------------------------------------

	//Some Basic validation functions
	function isValidEmail($input){
		if(preg_match('/[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+(?:\.[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+)*\@[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+(?:\.[^\x00-\x20()<>@,;:\\".[\]\x7f-\xff]+)+/i',$input)){ 
			return true; }else{ return false; }
	}
	function isValidUSZip($input){
		if(preg_match("/[0-9]{5}|[0-9]{5}\-[0-9]{4}/",$input)){ return true; }else{ return false; }
	}

	//----------------------------------------
	//Types of inputs
	function form_display_text($disp_text,$name,$value='',$size='20',$maxlength=''){
		$value=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td><input type=\"text\" name=\"".$name."\" value=\"".$value."\" size=\"".$size."\" ";
		if(!empty($maxlength)){ echo "maxlength=\"".$maxlength."\""; }
		echo "/></td>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_radio($disp_text,$name,$options,$selected=''){
		$selected=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<tr>";
		echo "<td id=\"".$name."_title\" class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td id=\"".$name."_disp\">";
		$count=1;
		foreach($options as $key => $value){ 
			echo "<input type=\"radio\" name=\"".$name."\" value=\"".$key."\" ";
			if(strtoupper($selected)==strtoupper($key)){ echo "CHECKED"; }
			if(isset($this->onClick[$name."_".$key])){ echo "onClick=\"".$this->onClick[$name."_".$key]."(".$count.",'".$name."')\""; }
			echo " >".$value."\n";
			$count++;
		}
		echo "</td>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_password($disp_text,$name,$size='20'){
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td><input type=\"password\" name=\"".$name."\" size=\"".$size."\"/></td>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_textarea($disp_text,$name,$value='',$cols='20',$rows='5'){
		$value=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<tr>";
		echo "<td class=\"display_text\" style=\"vertical-align:top\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td><textarea wrap=\"virtual\" name=\"".$name."\" cols=\"".$cols."\" rows=\"".$rows."\">".$value."</textarea>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_select($disp_text,$name,$options,$selected='',$use_vals_as_keys='0'){
		$selected=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td><select name=\"".$name."\">";
		foreach($options as $key => $value){
			if($use_vals_as_keys!="1"){ echo "<option value=\"".$key."\" "; }else{ echo "<option value=\"".$value."\" "; }
			if(strtoupper($selected)==strtoupper($key)){ echo "SELECTED"; }
			echo ">".$value."\n";
		}
		echo "</select></td>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_checkbox($disp_text,$name,$options,$selected=''){
		$selected=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td>";
		foreach($options as $key => $value){
			echo "<input type=\"checkbox\" name=\"".$name."[]\" value=\"".$value."\" ";
			if(strtoupper($selected)==strtoupper($value)){ echo "CHECKED"; }
			echo ">".$value."\n";
		}
		echo "</td>";
		echo "</tr>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_hidden($name){
		$value=($this->getVal($name)) ? $this->getVal($name) : "";
		echo "<input type=\"hidden\" name=\"".$name."\" value=\"".$value."\"/>\n";
		if(in_array($name,$this->errored_fields)){ $this->displayError($this->required_msgs[$name]); }
	}
	function form_display_upload($disp_text,$name){
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":".$this->displayRequired($name)."</td>";
		echo "<td><input type=\"file\" name=\"".$name."\"/></td>";
		echo "</tr>";
	}

	function form_display_plaintext($disp_text,$data){
		echo "<tr>";
		echo "<td class=\"display_text\">".$disp_text.":</td><td style=\"font-size:11px\">".$data."</td>";
		echo "</tr>\n";
	}
	function form_display_msg($disp_text){
		echo "<tr>";
		//echo "<td>&nbsp;</td><td class=\"plain_display_text\">".$disp_text."</td>";
		echo "<td colspan=\"2\" class=\"plain_display_text\">".$disp_text."</td>";
		echo "</tr>\n";
	}
	function form_display_header($disp_text){
		echo "<tr>";
		echo "<td class=\"header_display_text\" colspan=\"2\">".$disp_text."</td>";
		echo "</tr>";
	}
	function form_display_submit(){
		echo "<tr>";
		echo "<td colspan=\"2\" align=\"right\">";
		echo "<input type=\"submit\" name=\"".$this->submit_text."\" value=\"".$this->submit_text."\">";
		echo "</td>";
		echo "</tr>\n";
	}
	//----------------------------------------
	
	function form_display(){
		$action=(empty($this->form_action)) ? $_SERVER['PHP_SELF'] : $this->form_action;

		echo "<form action=\"".$action."\" method=\"POST\" name=\"".$this->form_name."\" id=\"".$this->form_name."\" enctype=\"multipart/form-data\">\n";
		echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"".$this->form_table_name."\">\n";
		$this->form_body();
		echo "</table>\n";
		echo "</form>";
	}
	function run(){ //print_r($_POST);
		$this->form_prepare();
		if(isset($_POST[str_replace(" ","_",$this->submit_text)])){
			foreach($_POST as $key => $value){
				if($this->isRequired($key)){
					if(method_exists($this,"form_validate_".strtolower($key))){
						//first, just be sure that it's set
						if(empty($value) || !isset($value)){ 
							$this->errored_fields[]=$key; 
						}else{
							//run the custom function
							$func_name="form_validate_".strtolower($key); //echo $func_name;
							$this->$func_name($key,$value);
						}
					}else{
						//just check to be sure that there's something in it
						if(empty($value) || !isset($value)){ $this->errored_fields[]=$key; }
					}
				}else{

				}
			}
			if(count($this->errored_fields)>0){
				//we have errors, go back and show them
				$this->form_display();
			}else{
				$this->form_exec();
			}
		}else{
			$this->form_display();
		}
	}
	
	/**********************************************
	custom validate function definition
	function form_validate_foo($key,$data){
		if($data=="bar"){
			$this->errored_fields[]=$key;
		}else{ return true; }
	}
	**********************************************/
}
?>