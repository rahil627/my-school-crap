<?php
// +---------------------------------------------------------------------------+
// | Copyright (c) 2005, Chris Cornutt	                                       |
// | All rights reserved.                                                      |
// |                                                                           |
// | Redistribution and use in source and binary forms, with or without        |
// | modification, are permitted provided that the following conditions        |
// | are met:                                                                  |
// |                                                                           |
// | o Redistributions of source code must retain the above copyright          |
// |   notice, this list of conditions and the following disclaimer.           |
// | o Redistributions in binary form must reproduce the above copyright       |
// |   notice, this list of conditions and the following disclaimer in the     |
// |   documentation and/or other materials provided with the distribution.    |
// | o The names of the authors may not be used to endorse or promote          |
// |   products derived from this software without specific prior written      |
// |   permission.                                                             |
// |                                                                           |
// | THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS       |
// | "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT         |
// | LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR     |
// | A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT      |
// | OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,     |
// | SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT          |
// | LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,     |
// | DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY     |
// | THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT       |
// | (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE     |
// | OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.      |
// |                                                                           |
// +---------------------------------------------------------------------------+

class userManage {

	function userManage(&$db_obj){
		$this->db=$db_obj;
	}
	
	//-----------------------------
	function isLoggedIn(){
		if(isset($_SESSION['username'])){ return true; }else { return false; }
	}
	function isAdmin(){
		if(isset($_SESSION['admin']) && $_SESSION['admin']=="1"){ return true; }else{ return false; }
	}
	function getUserID(){ return $_SESSION['ID']; }
	function getUsername(){ return $_SESSION['username']; }
	function login($data){
		$user_info=$this->getUserInfo($data['username'],"username");
		if((md5($data['password'])==$user_info['password']) || ($data['password']==$user_info['password'])){
			unset($user_info['password']);
			foreach($user_info as $key => $value){
				$_SESSION[$key]=$value;
			}
			return true;
		}
		return false;
	}
	function logoff(){
		@session_destroy();
		@session_unset();
		$sessionid=session_name();
		setcookie ($sessionid, "", time()-3600);
		header("Location: index.php");
	}

	//-----------------------------
	function addUser($data){
		//echo "<pre>"; print_r($data); echo "</pre>";
		$sql=$this->db->buildInsert("users",$data); //echo "SQL: ".$sql."<br/>";
		$this->db->query("send",$sql);
		$this->login($data);
	}
	function deleteUser($user_id){
		$sql="delete from users where ID='".$user_id."'"; //echo $sql."<br/>";
		return $this->db->query("send",$sql);
	}
	function updateUser($user_id,$data){
		$sql=$this->db->buildUpdate("users",$data,"where ID='".$user_id."'");
		//echo "SQL: ".$sql."<br/>";
		return $this->db->query("send",$sql);
	}

	
	//-----------------------------
	function getUserInfo($data='',$type='ID'){
		$sql="select username,password,email,join_date,admin,ID from users ";
		if(!empty($data)){
			$sql.="where ";
			switch(strtolower($type)){
				case "id":			$sql.="ID='".$data."'"; break;
				case "username":	$sql.="lower(username)='".strtolower($data)."'"; break;
			}
		}
		$results=$this->db->query("get",$sql); //echo "<pre>"; print_r($results); echo "</pre>";
		if(!empty($data)){ return $results[0]; }else{ return $results; }
	}
}

?>