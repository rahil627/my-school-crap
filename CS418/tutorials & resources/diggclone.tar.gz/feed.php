<?php
header("Content-Type: text/xml");

//feed.php
include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/feedManage.php");
$feed=new feedManage();

$cat		= (isset($_GET['cat'])) ? $_GET['cat'] : '';
$page		= (isset($_GET['page'])) ? $_GET['page'] : '';
$promoted	= (isset($_GET['promoted'])) ? $_GET['promoted'] : '';
$items=$feed->digg->getStoryData('',$page,$promoted,$cat);

$feed->buildXML($items);
?>