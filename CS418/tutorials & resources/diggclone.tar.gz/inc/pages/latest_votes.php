

<h2>Latest Votes</h2>

<script>
function DoSomethingUseful(){
	getLatestVotes();
	setTimeout("DoSomethingUseful()",5000);
}
getLatestVotes();
setTimeout("DoSomethingUseful()",5000);
</script>

<div id="vote_list">

</div>