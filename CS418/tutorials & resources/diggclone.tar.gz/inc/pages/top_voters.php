<?php
$voters=$digg->getTopVoters();
//echo "<pre>"; print_r($voters); echo "</pre>";
?>

<table cellpadding="0" cellspacing="0" border="0" id="top_voters">
<tr><td class="header">User</td><td class="header">Votes</td></tr>
<?php
$i=0;
foreach($voters as $key => $value){
	$class=(($i%2)=="0") ? "row_white" : "row_grey";
	echo "<tr><td class=\"".$class."\">".$value['username']."</td><td class=\"".$class."\" align=\"right\">".$value['vote_count']."</td></tr>\n";
	$i++;
}
?>
</table>