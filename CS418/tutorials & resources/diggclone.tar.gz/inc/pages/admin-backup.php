<?php

if($digg->user->isLoggedIn() && $digg->user->isAdmin()){ 
include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/formManage.php");
?>
<table cellpadding="0" cellspacing="0" border="0">
<tr>
	<td style="border:1px solid #CCCCCC;padding:3px;width:100px;background-color:#EEEEEE;vertical-align:top">
		<a style="font-size:10px" href="<?=$_SERVER['PHP_SELF']?>?s=page&n=admin">admin home</a><br/>
		<br/>
		<a style="font-size:10px" href="<?=$_SERVER['PHP_SELF']?>?s=page&n=admin&do=list_links">list links</a><br/>
		<a style="font-size:10px" href="<?=$_SERVER['PHP_SELF']?>?s=page&n=admin&do=list_users">list users</a><br/>
	</td>
	<td style="padding:3px;vertical-align:top">
		<?php
			if(isset($_GET['do'])){
				switch(strtolower($_GET['do'])){
					case "edit_user":
						$user=$digg->user->getUserInfo($_GET['id']);
						//print_r($user);

						class user_edit_form extends formManage {
							function user_edit_form($user_data){
								$this->user=$user_data;
							}
							function form_prepare(){
								$this->setVal("email",$this->user['email']);
							}
							function form_body(){
								$this->form_display_plaintext("Username",$this->user['username']);
								$this->form_display_password("Update Password","pass1");
								$this->form_display_password("Confirm Password","pass2");
								$this->form_display_text("Email Address","email");
								$this->form_display_radio("Make Admin","make_admin",array("Yes","No"));
								$this->form_display_submit();
							}
							function form_exec(){
								unset($_POST[$this->submit_text]);
								echo "<pre>"; print_r($_POST); echo "</pre>";
							}
						}
						$u=new user_edit_form($user);
						$u->run();
						break;
					case "list_links": 

						break;
					case "list_users":
						if(isset($_POST['submit_pro'])){

							//promote selected users to admins
							unset($_POST['submit_pro']);
							echo "<pre>"; print_r($_POST); echo "</pre>";
							foreach($_POST as $key => $value){
								preg_match("/delete_([0-9]+)/",$key,$result); //print_r($result);
								if($digg->user->updateUser($result[1],array("admin"=>"1"))){
									echo "User #".$result[1]." promoted to admin successfully!<br/>";
								}else{ echo "There was an error updating the information of user #".$result[1]."<br/>"; }
							}

						}elseif(isset($_POST['submit_del'])){

							//delete selected users...
							unset($_POST['submit_del']);
							//echo "<pre>"; print_r($_POST); echo "</pre>";
							foreach($_POST as $key => $value){
								preg_match("/delete_([0-9]+)/",$key,$result); //print_r($result);
								if($digg->user->deleteUser($result[1])){
									echo "User #".$result[1]." removed successfully!<br/>";
								}else{ echo "There was an error removing user #".$result[1]."<br/>"; }
							}
						}else{
							echo "<h3>User list</h3>";
							$users=$digg->user->getUserInfo(); //echo "<pre>"; print_r($users); echo "</pre>";
							
							$i=0;
							echo "<form action=\"".$_SERVER['PHP_SELF']."?s=page&n=admin&do=list_users\" method=\"POST\">\n";
							echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"display_table\">\n";
							echo "<tr><td class=\"table_header\" align=\"center\">&nbsp;</td><td class=\"table_header\">Username</td>";
							echo "<td class=\"table_header\">Email</td><td class=\"table_header\">Date Joined</td><td class=\"table_header\">Is Admin</td><td class=\"table_header\">Edit</td></tr>\n";
							foreach($users as $key => $value){
								$style=(($i%2)=="0") ? "white" : "grey";
								echo "<tr>\n";
								echo "<td class=\"table_row_".$style."\"><input type=\"checkbox\" name=\"delete_".$value['ID']."\" value=\"1\"></td>\n";
								echo "<td class=\"table_row_".$style."\">".$value['username']."</td>\n";
								echo "<td class=\"table_row_".$style."\">".$value['email']."</td>\n";
								echo "<td class=\"table_row_".$style."\">".date("m.d.Y H:i:s",$value['join_date'])."</td>\n";
								echo "<td align=\"center\" class=\"table_row_".$style."\">".(($value['admin']=="1") ? "Yes" : "No")."</td>\n";
								echo "<td align=\"center\" class=\"table_row_".$style."\"><a href=\"".$_SERVER['PHP_SELF']."?s=page&n=admin&do=edit_user&id=".$value['ID']."\">edit</a></td>\n";
								echo "</tr>\n";
								$i++;
							}
							echo "<tr><td colspan=\"6\" align=\"center\">";
							echo "<input type=\"submit\" name=\"submit_del\" value=\"delete selected\"/>";
							echo "<input type=\"submit\" name=\"submit_pro\" value=\"promote to admin\"/>";
							echo "</td></tr>";
							echo "</table>\n\n";
						}
						break;
				}
			}else{ echo "Please select an option from the left...<br/>"; }
		?>
	</td>
</tr>
</table>
<?php
}else{ 
	echo "<span style=\"color:#DF0005\"><b>NOTE:</b> You are not allowed to access this resource!</span>";
}
?>