<style>
	.top_admin_links { font-size: 10px; font-weight: bold; }
	.top_admin_links a { text-decoration: none; }

	#data_table td { font-size: 10px; padding: 4px; }
	#data_table td.tr_white { background-color: #FFFFFF; }
	#data_table td.tr_grey { background-color: #EEEEEE; }
</style>

<?php

if($digg->user->isLoggedIn() && $digg->user->isAdmin()){ 
	include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/formManage.php");
	?>
	
	<table cellpadding="0" cellspacing="0" border="0">
	<tr>
		<td class="top_admin_links">[<a href="index.php?s=page&n=admin&do=users">USERS</a>]</td>
		<td class="top_admin_links">[<a href="index.php?s=page&n=admin&do=posts">POSTS</a>]</td>
		<td class="top_admin_links">[<a href="index.php?s=page&n=admin&do=sections">SECTIONS</a>]</td>
	</tr>
	<tr>
		<td colspan="3">
		<?php
		if(isset($_GET['do'])){
			switch(strtolower($_GET['do'])){
				case "users": 
					echo "editing users...<hr/>";
					
					if(isset($_POST['users_rem_submit'])){
						//echo "<pre>"; print_r($_POST); echo "</pre>";
						if(!empty($_POST['items'])){
							foreach($_POST['items'] as $key => $value){
								$digg->user->deleteUser($value);
								echo "Removing user ID #".$value."<br/>\n";
							}
						}
						echo "<hr/>";
					}
					
					if(isset($_GET['edit'])){
						class userInfo extends formManage {
							function userInfo(&$digg_obj){
								$this->digg_obj=$digg_obj;
							}
							//---------------------
							function form_prepare(){
								$this->form_action="index.php?s=page&n=admin&do=users";
								$this->validate("email","You must enter an email address for the user!");

								if(isset($_GET['edit'])){
									$this->form_action.="&edit=".$_GET['edit'];
									$this->user=$this->digg_obj->user->getUserInfo($_GET['edit']); //print_R($this->user);
									$this->setVal("email",$this->user['email']);
									$this->setVal("user_id",$this->user['ID']);
									$this->setVal("is_admin",($this->user['admin']=="1") ? "Yes" : "");
								}
							}
							function form_body(){
								$this->form_display_plaintext("Username",$this->user['username']);
								$this->form_display_password("Update Password","pass1");
								$this->form_display_password("Confirm Password","pass2");
								$this->form_display_text("Email Address","email",'',30);
								$this->form_display_checkbox("Is Admin","is_admin",array("Yes"));
								if(isset($_GET['edit'])){
									$this->form_display_hidden("user_id");
								}
								$this->form_display_submit();
							}
							function form_exec(){
								$_POST['admin']=(isset($_POST['is_admin'])) ? "1" : "0";
								if( (!empty($_POST['pass1']) && !empty($_POST['pass2'])) && ($_POST['pass1']==$_POST['pass2']) ){
									$_POST['password']=md5($_POST['pass1']);
								}
								$user_id=$_POST['user_id'];
								unset($_POST['is_admin'],$_POST[$this->submit_text],$_POST['pass1'],$_POST['pass2'],$_POST['user_id']);

								//echo "<pre>"; print_r($_POST); echo "</pre>";
								$this->digg_obj->user->updateUser($user_id,$_POST);

								echo "User information updated!<br/>\n";
							}
						}
						$ui=new userInfo($digg);
						$ui->run();
					}else{
						//by default, show user list
						$user_info=$digg->user->getUserInfo(); //echo "<pre>"; print_r($user_info); echo "</pre>";
						echo "<form action=\"index.php?s=page&n=admin&do=users\" method=\"POST\">\n";
						echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"data_table\">";
						$i=0;
						foreach($user_info as $key => $value){
							$style=(($i%2)=="0") ? "white" : "grey";
							echo "<tr><td class=\"tr_".$style."\"><input type=\"checkbox\" name=\"items[]\" value=\"".$value['ID']."\"></td>";
							echo "<td class=\"tr_".$style."\">".$value['username']."</td>";
							echo "<td class=\"tr_".$style."\"><a href=\"index.php?s=page&n=admin&do=users&edit=".$value['ID']."\">edit</a></td></tr>\n";
							$i++;
						}
					}
					echo "<tr><td colspan=\"4\" align=\"right\"><input type=\"submit\" name=\"users_rem_submit\" value=\"remove selected\"/></td>";
					echo "</table>";
					echo "</form>";
					break;
				case "posts": 
					
					/*$sql="select p.title,p.date_posted,p.category,p.ID,count(distinct pv.ID) as vote_count, count(distinct pcom.ID) as comment_count from posts p, post_cats pc, users u left join post_votes pv on pv.post_id=p.ID left join post_comments pcom on pcom.post_id=p.ID where pc.ID=p.category group by p.title,p.date_posted,p.category,p.ID";*/

					$sql="select title,date_posted,category,ID from posts";
					$sql.=" order by date_posted desc limit 20";
					$results=$digg->db->query("get",$sql);
					//echo "SQL: ".$sql."<br/>";

					//echo "<pre>"; print_r($results); echo "</pre>";

					echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"data_table\">\n";
					$i=0;
					foreach($results as $key => $value){
						$style=(($i%2)=="0") ? "white" : "grey";
						echo "<tr><td class=\"tr_".$style."\">[<a href=\"index.php?s=form&n=edit_post&id=".$value['ID']."\">edit</a>]</td>";
						echo "<td class=\"tr_".$style."\">[<a href=\"index.php?s=form&n=del_post&id=".$value['ID']."\">delete</a>]</td>";
						echo "<td class=\"tr_".$style."\">".date("m.d.Y H:i:s",$value['date_posted'])."</td>";
						echo "<td class=\"tr_".$style."\">".$value['title']."</td></tr>";
						$i++;
					}
					echo "</table>";

					break;
				case "sections": 
					echo "editing sections...<hr/>";

					if(isset($_POST['section_rem_submit'])){
						//echo "<pre>"; print_r($_POST); echo "</pre>";
						if(!empty($_POST['items'])){
							foreach($_POST['items'] as $key => $value){
								$digg->deletePostCatData($value);
								echo "Removing category: ".$value."<br/>";
							}
						}
						echo "<hr/>";
					}
					
					echo "<span class=\"top_admin_links\">[<a href=\"index.php?s=page&n=admin&do=sections&add=1\">ADD NEW SECTION</a>]</span>";
					$topics=$digg->getCategoryInfo();
					//echo "<pre>"; print_r($topics); echo "</pre>";
					if(isset($_GET['edit']) || $_GET['add']){
						class sectionEdit extends formManage {
							function sectionEdit(&$digg){
								$this->digg=$digg;
							}
							function form_prepare(){
								$this->form_action="index.php?s=page&n=admin&do=sections";
								if(isset($_GET['edit'])){
									$cat_info=$this->digg->getCategoryInfo($_GET['edit']); //print_r($cat_info);
									$this->form_action.="&edit=".$_GET['edit'];

									$this->setVal("cat_id",$_GET['edit']);
									$this->setVal("cat_title",$cat_info[0]['cat_title']);
									$this->setVal("cat_desc",$cat_info[0]['cat_desc']);
								}elseif(isset($_GET['add'])){
									$this->form_action.="&add=1";
								}
							}
							function form_body(){
								$this->form_display_text("Title","cat_title");
								$this->form_display_text("Description","cat_desc",'',40);
								$this->form_display_hidden("cat_id");
								$this->form_display_submit();
							}
							function form_exec(){
								//echo "<pre>"; print_r($_POST); echo "</pre>";
								if(!empty($_POST['cat_id'])){
									$cat_id=$_POST['cat_id'];
									unset($_POST[$this->submit_text],$_POST['cat_id']);
									$this->digg->updatePostCatData($_POST,$cat_id);

									echo "<br/>Category Information Updated!<br/>";
								}else{
									unset($_POST[$this->submit_text],$_POST['cat_id']);
									$this->digg->insertPostCatData($_POST);

									echo "<br/>Category Information Inserted!<br/>";
								}
							}
						}
						$se=new sectionEdit($digg);
						$se->run();
					}else{
						//list the current sections
						echo "<form action=\"index.php?s=page&n=admin&do=sections\" method=\"POST\">\n";
						echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\" id=\"data_table\">";
						$i=0;
						foreach($topics as $key => $value){
							$style=(($i%2)=="0") ? "white" : "grey";
							echo "<tr><td class=\"tr_".$style."\"><input type=\"checkbox\" name=\"items[]\" value=\"".$value['ID']."\"></td>";
							echo "<td class=\"tr_".$style."\">".$value['cat_title']."</td>";
							echo "<td class=\"tr_".$style."\" width=\"50\">".$value['cat_desc']."</td>";
							echo "<td class=\"tr_".$style."\"><a href=\"index.php?s=page&n=admin&do=sections&edit=".$value['ID']."\">edit</a></td></tr>\n";
							$i++;
						}
						echo "<tr><td colspan=\"4\" align=\"right\"><input type=\"submit\" name=\"section_rem_submit\" value=\"remove selected\"/></td>";
						echo "</table>\n";
						echo "</form>\n";
					}
					break;
			}
		}
		?>
		</td>
	</tr>
	</table>

	<?php
}else{ echo "You're not allowed to be here!<br/>"; }
?>