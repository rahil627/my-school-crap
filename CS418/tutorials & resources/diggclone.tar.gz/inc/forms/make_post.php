<?php

class make_post extends formManage {

	function make_post(){
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php");
		$this->digg=new diggManage(); //print_r($this->digg);
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/userManage.php");
		$this->user=new userManage();
	}

	function form_prepare(){
		$this->form_action="/diggclone/index.php?s=form&n=make_post";

		$this->validate("title","You must enter a title for the post!");
		$this->validate("content","You must enter content for the post!");
		$this->validate("category","Please select a valid category for the post!");
		$this->validate("url","You must enter a URL for the site you're posting!");

		$cat_data=$this->digg->getPostCatData();
		foreach($cat_data as $key => $value){ $this->cats[$value['ID']]=$value['cat_title']; }
	}
	function form_body(){
		$this->form_display_text("Title","title",'',47);
		$this->form_display_textarea("Content","content",'',35,10);
		$this->form_display_select("Category","category",$this->cats);
		$this->form_display_text("URL","url",'',47);
		$user=($this->user->isLoggedIn()) ? $this->user->getUsername() : 'Anonymous';
		$this->form_display_plaintext("User",$user);
		if(isset($_GET['id'])){ $this->form_display_hidden("post_id"); }
		$this->form_display_submit();
	}
	function form_exec(){
		unset($_POST[$this->submit_text]);
		$_POST['date_posted']=time();
		if($this->user->isLoggedIn()){
			$_POST['submitted_user_id']=$this->user->getUserID();
		}else{ $_POST['submitted_user_id']="1"; }

		//echo "<pre>"; print_r($_POST); echo "</pre>";
		$this->digg->insertStory($_POST);
		echo "Story inserted!<br/>";
	}

}

?>