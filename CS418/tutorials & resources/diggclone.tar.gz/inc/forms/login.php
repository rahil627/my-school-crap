<?php

class login extends formManage {

	function login(&$digg_obj){
		$this->digg=$digg_obj;
	}

	function form_prepare(){
		$this->form_action=$_SERVER['PHP_SELF']."?s=form&n=login";

		$this->validate("username","You must enter a valid username!");
		$this->validate("password","You must enter a password!");
	}
	function form_body(){
		$this->form_display_text("Username","username");
		$this->form_display_password("Password","password");
		$this->form_display_hidden("msg");
		$this->form_display_submit();
		$this->form_display_msg("[<a href=\"".$_SERVER['PHP_SELF']."?s=form&n=make_login\">create a login</a>]");
	}
	function form_exec(){
		unset($_POST[$this->submit_text]);
		//echo "<pre>"; print_r($_POST); echo "</pre>";

		if($this->digg->user->login($_POST)){
			echo "<meta http-equiv=\"Refresh\" content=\"0;url=index.php\">";
		}else{
			$this->setErrorMsg("msg","There was an error with your login information!");
			$this->errored_fields[]="msg";
			$this->form_display();
		}
	}

}

?>