<?php

class make_login extends formManage {

	function make_login(&$digg_obj){	
		$this->digg=$digg_obj;
	}

	function form_prepare(){
		$this->form_action=$_SERVER['PHP_SELF']."?s=form&n=make_login";

		$this->validate("username","You must enter a valid username!");
		$this->validate("password","You must enter a password!");
		$this->validate("confirm_pass","You must confirm the password!");
		$this->validate("email","You must enter a valid email address!");
	}
	function form_body(){
		$this->form_display_text("Username","username");
		$this->form_display_password("Password","password");
		$this->form_display_password("Confirm Password","confirm_pass");
		$this->form_display_text("Email","email");
		$this->form_display_submit();
	}
	function form_exec(){
		unset($_POST[$this->submit_text],$_POST['confirm_pass']);
		$_POST['join_date']=time();
		$_POST['admin']="0";
		$_POST['password']=md5($_POST['password']);
		//echo "<pre>"; print_r($_POST); echo "</pre>";

		$this->digg->user->addUser($_POST);
		echo "User has been added! You can now vote for your <a href=\"\">favorite articles</a>!";
	}

	//-------------------------------
	function form_validate_username($key,$data){
		$data=$this->digg->user->getUserInfo($data,"username"); //print_r($data);
		if(!empty($data)){ 
			$this->setErrorMsg($key,"There is already a user with the name.<br/> Please try again!");
			$this->errored_fields[]=$key;
			return false; 
		}else{ return true; }
	}
	function form_validate_confirm_pass($key,$data){
		if($data!=$_POST['password']){
			$this->setErrorMsg($key,"Passwords to not match! Please try again!");
			$this->errored_fields[]=$key;
			return false; 
		}else{ return true; }
	}
	function form_validate_email($key,$data){
		if(!$this->isValidEmail($data)){
			$this->setErrorMsg($key,"Not a valid email address! Please try again!");
			$this->errored_fields[]=$key;
			return false; 
		}else{ return true; }
	}

}

?>