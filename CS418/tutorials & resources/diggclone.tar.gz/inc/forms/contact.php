<?php

class contact extends formManage {

	var $to_addr="enygma@phpdeveloper.org";

	function contact(){
	}

	//-----------------------------
	function form_prepare(){
		$this->form_action=$_SERVER['PHP_SELF']."?s=form&n=contact";

		$this->validate("name","You must enter a name!");
		$this->validate("email","You must enter an email address!");
		$this->validate("comment","You must enter a comment!");
	}
	function form_body(){
		$this->form_display_header("Contact Us");
		$this->form_display_text("Name","name");
		$this->form_display_text("Email","email");
		$this->form_display_textarea("Comment","comment",'',40,10);
		$this->form_display_submit();
	}
	function form_exec(){
		//echo "<pre>"; print_r($_POST); echo "</pre>";
		unset($_POST[$this->submit_text]);
		$string="";
		foreach($_POST as $key => $value){
			$string.="[".$key."] => ".$value."\n\n";
		}
		mail($this->to_addr,"Contact Us Form - diggClone",$string,"From: siteMonitor@talkingpixels.org");

		echo "<b><span style=\"color:#D90000\">NOTE:</span> Email sent!</b><br/><br/>";
	}

}

?>