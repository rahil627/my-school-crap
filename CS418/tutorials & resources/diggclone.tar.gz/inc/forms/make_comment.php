<?php

class make_comment extends formManage {


	function make_comment(){
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php");
		$this->digg=new diggManage(); //print_r($this->digg);
	}

	function form_prepare(){
		$this->form_action=$_SERVER['REQUEST_URI'];
		$this->setVal("post_id",$_GET['post_id']);
		$this->setVal("user_id",$this->digg->user->getUserID());
	}
	function form_body(){
		$this->form_display_text("Title","title");
		$this->form_display_textarea("Comment","content");
		$this->form_display_hidden("post_id");
		if($this->digg->user->isLoggedIn()){
			$this->form_display_plaintext("User","me");
			$this->form_display_hidden("user_id");
		}else{
			$this->form_display_plaintext("User","Anonymous");
		}
		$this->form_display_submit();
	}
	function form_exec(){
		unset($_POST[$this->submit_text]);
		$_POST['date_posted']=time();
		if(!isset($_POST['user_id'])){ $_POST['user_id']="0"; }
		//echo "<pre>"; print_r($_POST); echo "</pre>";
		$this->digg->postComment($_POST);

		echo "Comment Added!<br/><br/>";
	}

}


?>