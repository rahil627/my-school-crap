<?php

class del_post extends formManage {

	function del_post(){
		include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php");
		$this->digg=new diggManage(); //print_r($this->digg);
	}

	function form_prepare(){
		$this->submit_text="Yes";
		$this->setVal("post_id",$_GET['id']);
		$this->form_action=$_SERVER['PHP_SELF']."?s=form&n=del_post";
	}
	function form_body(){
		$this->form_display_msg("Are you sure you wish to delete post ID #".$_GET['id']."?");
		$this->form_display_hidden("post_id");
		$this->form_display_submit();
	}
	function form_exec(){
		$this->digg->deleteStory($_POST['post_id']);
	}

}

?>