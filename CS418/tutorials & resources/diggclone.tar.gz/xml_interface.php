<?php 
include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php");
$digg=new diggManage();
header("Content-Type: text/xml");
echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"; ?>
<root>
<?php
if(isset($_GET['post_id'])){
	if(!$digg->checkVotesUser($_GET['post_id'],$_GET['user_id'])){
		$digg->addVote($_GET['post_id'],$_GET['user_id']);
	}else{
		echo "<error>You have already voted for this item!</error>";
	}
	echo "<data>".$digg->getVotes($_GET['post_id'])."</data>";
	echo "<post_id>".$_GET['post_id']."</post_id>";
}elseif(isset($_GET['latest_votes'])){
	$votes=$digg->getLatestVotes(); //echo "<pre>"; print_r($votes); echo "</pre>";
	foreach($votes as $key => $value){
		echo "<vote_data>\n";
		foreach($value as $ikey => $ivalue){
			echo "<".$ikey.">".str_replace("&","and",$ivalue)."</".$ikey.">\n";
		}
		echo "</vote_data>\n";
		/*
		echo "<vote_data>\n";
		echo "<post_id>".$value['post_id']."</post_id>\n";
		echo "<date_voted>".date("m.d.Y H:i:s",$value['date_voted'])."</date_voted>\n";
		echo "<title>".$value['title']."</title>\n";
		echo "<votes>".$value['vote_count']."</votes>\n";
		echo "<content>".substr(str_replace("&","&nbsp;",$value['content']),0,200)."</content>\n";
		echo "<username>".$value['username']."</username>\n";
		echo "<comment_count>".$value['comment_count']."</comment_count>\n";
		echo "<cat_title>".$value['cat_title']."</cat_title>";
		echo "</vote_data>\n";
		*/
	}
}
?>
</root>