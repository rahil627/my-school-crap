create database diggclone;
use diggclone;

create table users (
	username VARCHAR(100),
	password VARCHAR(32),
	email VARCHAR(200),
	join_date INT,
	admin enum('0','1'),
	ID INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(ID)
);

create table posts (
	title VARCHAR(200),
	content TEXT,
	date_posted INT,
	category INT,
	url VARCHAR(200),
	submitted_user_id INT,
	ID INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(ID)
);

create table post_comments (
	title VARCHAR(200),
	content TEXT,
	user_id INT,
	post_id INT,
	date_posted INT,
	ID INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(ID)
);

create table post_cats (
	cat_title VARCHAR(100),
	cat_desc TEXT,
	ID INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(ID)
);

create table post_votes (
	post_id INT,
	user_id INT,
	date_voted INT,
	ID INT NOT NULL AUTO_INCREMENT,
	PRIMARY KEY(ID)
)