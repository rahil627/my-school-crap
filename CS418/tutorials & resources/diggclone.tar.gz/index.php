<?php
session_start();
include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/diggManage.php"); $digg=new diggManage();
if(isset($_GET['do']) && $_GET['do']=="logoff"){ $digg->user->logoff(); }
?>
<html>
<head>
<title>diggClone</title>
<link rel="StyleSheet" href="inc/site_style.css" TYPE="text/css"/>
</head>

<script>

function updateDiv(div_name,user_id){
	post_id=div_name.replace(/vote_count_/g,"");
	ajaxRead("http://www.talkingpixels.org/diggclone/xml_interface.php?post_id="+post_id+"&user_id="+user_id);
}
function getLatestVotes(){
	ajaxRead("http://www.talkingpixels.org/diggclone/xml_interface.php?latest_votes=1");
}
function parseLatestVotes(xmlObj){
	len=xmlObj.responseXML.getElementsByTagName('vote_data').length;

	mydiv=document.getElementById("vote_list");
	mydiv.innerHTML='';
	for(i=0;i<len;i++){
		mydata=xmlObj.responseXML.getElementsByTagName('vote_data')[i];

		post_id		= mydata.getElementsByTagName('post_id')[0].firstChild.data;
		title		= mydata.getElementsByTagName('title')[0].firstChild.data;
		date_posted	= mydata.getElementsByTagName('date_posted')[0].firstChild.data;
		date_voted	= mydata.getElementsByTagName('date_voted')[0].firstChild.data;
		vote_count	= mydata.getElementsByTagName('vote_count')[0].firstChild.data;
		comment_count=mydata.getElementsByTagName('comment_count')[0].firstChild.data;
		content		= mydata.getElementsByTagName('content')[0].firstChild.data;
		cat_title	= mydata.getElementsByTagName('cat_title')[0].firstChild.data;
		cat_id		= mydata.getElementsByTagName('cat_id')[0].firstChild.data;
		username	= mydata.getElementsByTagName('username')[0].firstChild.data;
		url			= mydata.getElementsByTagName('url')[0].firstChild.data;
		sub_user	= mydata.getElementsByTagName('submitted_user_id')[0].firstChild.data;

		<!--new_string='<a class="latest_votes_link" href="'+post_id+'">'+title+'</a><br/>last vote: '+date_posted+'<br/><br/>';-->
		if(vote_count>=<?=$digg->promote_level?>){
			img="arrow.gif";
			cl="vote_block";
			comment_link="<?=$_SERVER['PHP_SELF']?>?post_id="+post_id;
			section_link="<?=$_SERVER['PHP_SELF']?>?cat_id="+cat_id;
		}else{
			img="arrow_fade.gif";
			cl="vote_block_fade";
			comment_link="<?=$_SERVER['PHP_SELF']?>?n=cast_votes&post_id="+post_id;
			section_link="<?=$_SERVER['PHP_SELF']?>?n=cast_votes&cat_id="+cat_id;
		}

		new_string='<table cellpadding="0" cellpaddding="0" border="0" id="post_table">'
		+'<tr><td class="'+cl+'" rowspan="4">'
		+'<span style="font-size:14px;font-weight:bold"><div style="padding:0px;margin:0px" id="vote_count_%s">'+vote_count+'</div></span>votes<br/>'
		+'<img src="img/'+img+'" border="0"/><br/><span style="font-size:9px">[vote]</span></a></td>'
		+'<td class="title"><a class="title_link" href="'+url+'">'+title+'</a></td></tr>'
		+'<tr><td class="submitted">submitted by <a href="index.php?user='+sub_user+'">'+username+'</a> at '+date_posted+'</td></tr>'
		+'<tr><td class="content">'+content+'</td></tr><tr><td><table cellpadding="0" cellspacing="0" border="0" id="post_table_sub">'
		+'<tr><td width="120"><a href="'+comment_link+'">'+comment_count+' comments</a></td><td width="120"><a href="">blog</a></td>'
		+'<td width="120" style="text-align:left;padding-left:40px">category: <a href="'+section_link+'">'+cat_title+'</a></td>'
		+'</tr></table></td></tr></table><br/>';

		mydiv.innerHTML=mydiv.innerHTML+new_string;
	}
}

function createRequestObject() {
	var ro;
    var browser = navigator.appName;
    if(browser == "Microsoft Internet Explorer"){
        ro = new ActiveXObject("Microsoft.XMLHTTP");
    }else{ ro = new XMLHttpRequest(); }
    return ro;
}

var xmlObj = createRequestObject();

function ajaxRead(file){
	xmlObj.open ('GET', file, true);
	xmlObj.onreadystatechange = handleResponse;
    xmlObj.send (null);
}
function handleResponse(){			
	if(xmlObj.readyState == 4){
		<!--alert(xmlObj.responseText);-->
		if(xmlObj.responseXML.getElementsByTagName('vote_data').length > 0){
			parseLatestVotes(xmlObj);
		}else{
			counter=xmlObj.responseXML.getElementsByTagName('data')[0].firstChild.data;
			post_id=xmlObj.responseXML.getElementsByTagName('post_id')[0].firstChild.data;

			
			if(xmlObj.responseXML.getElementsByTagName('error').length > 0){
				alert("Notice: "+xmlObj.responseXML.getElementsByTagName('error')[0].firstChild.data);
			}

			div_name="vote_count_"+post_id;
			mydiv=document.getElementById(div_name);
			mydiv.innerHTML=parseInt(counter);
		}
	}
}
</script>

<body>
<a href="index.php"><h1 style="margin:0px;padding:0px">DiggClone</h1></a>
a clone of the digg.com engine
<br/><br/>

<table cellpadding="0" cellspacing="0" border="0" id="main">
<tr>
	<td id="menu">
		[<a href="<?=$_SERVER['PHP_SELF']?>">home</a>]<br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?s=form&n=make_post">make post</a>]<br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?s=form&n=login">login</a>]<br/>
		<br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?n=cast_votes">cast your votes</a>]
		<br/><br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?s=form&n=contact">contact us</a>]<br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?s=page&n=top_voters">top voters</a>]<br/>
		[<a href="<?=$_SERVER['PHP_SELF']?>?s=page&n=latest_votes">latest votes</a>]<br/>
		<?php
		if($digg->user->isLoggedIn() && $digg->user->isAdmin()){ 
			echo "[<a href=\"".$_SERVER['PHP_SELF']."?s=page&n=admin\">admin</a>]<br/>";
		}
		?>
		<br/><br/>
		<h3 style="margin-bottom:2px">Categories</h3>
		<?php
		$cats=$digg->getCategoryData(); //echo "<pre>"; print_r($cats); echo "</pre>";
		$sec_url=($cast_votes) ? $_SERVER['PHP_SELF']."?n=cast_votes&cat_id" : $_SERVER['PHP_SELF']."?cat_id";
		foreach($cats as $key => $value){
			echo "[".$value['post_count']."] <a href=\"".$sec_url."=".$value['ID']."\">".$value['cat_title']."</a><br/>";
		}
		?>
		<br/>
		<?php
		if($digg->user->isLoggedIn()){ 
			echo "logged in as <b>".$digg->user->getUsername()."</b><br/>"; 
			echo "[<a href=\"".$_SERVER['PHP_SELF']."?do=logoff\">logoff</a>]";
		}
		?>
		<p>
		<form action="<?=$_SERVER['PHP_SELF']?>?search=1" method="POST">
		search:<br/>
		<input type="text" name="search_term" size="10"/>
		<input type="submit" name="submit" value="go"/>
		</form>
		<br/><br/>
		Main RSS: <a href="feed.php?promoted=1"><img src="img/xml.gif" border=\"0\"></a>
	</td>
	<td id="contents">
		<?php
		//echo "<pre>"; print_r($_SERVER); echo "</pre>";
		if($_SERVER['REQUEST_URI']=="/diggclone/index.php" || $_SERVER['REQUEST_URI']=="/diggclone/"){
		?>
		<div id="message">
		Welcome to the diggClone website!
		<p>
		The diggCLone project is an effort to reproduce the functionality of the oh-so-popular social bookmarking site, <a href="http://www.digg.com">digg.com</a>. We've changed up a few things about it, but kept how the site basically works. Right now, we're still in some of the early stages, though, so some of the functionality isn't there yet.
		<p>
		Here's what we have so far - you can:
		<ul>
		<li>signup a new user
		<li>make a post to one of the categories
		<li>place votes (once logged in)
		<li>place comments on the posts
		<li>and, of course, view all of the results of the various links (comments/sections/posts)
		</ul>
		<p>
		The voting is all handled through a simple Ajax interface so that the page doesn't even need to reload to accomplish its job. Items will get automatically promoted to the front page when they hit the threshold set in the diggManage class (default is 20 votes).
		<p>
		To download this project, you can <a href="diggclone.tar.gz">click here to grab the tar/gzip file</a> (version 0.5).<br/>
		If you would like to contact me about this project, you can reach me at <a href="mailto:enygma@phpdeveloper.org">enygma@phpdeveloper.org</a> or you can use <a href="<?=$_SERVER['PHP_SELF']?>?s=form&n=contact">our Contact Us form</a>.
		<p>
		If you would like to try out the "user only" features, you can use the test account: test/test
		<p>
		For the latest update information, check out <a href="CHANGELOG">the CHANGELOG</a>.
		<p>
		Seems that we've been <a href="http://www.digg.com/programming/Want_your_own_Digg_Website_">noticed on Digg.com</a> - vote away! :)<br/>
		Some of the comments on there note that there's not really a license associated with this software - honestly, if I knew how to apply a GPL license to it, I would. If you know the simple steps to it, <a href="mailto:enygma@phpdeveloper.org">email me</a> or use the <a href="http://www.talkingpixels.org/diggclone/index.php?s=form&n=contact">contact us</a> form...
		<p>
		<?php
		$file=$_SERVER['DOCUMENT_ROOT']."/diggclone/count.txt";
		$content=file($file);
		if($_SERVER['REMOTE_ADDR']!="63.166.247.24"){
			$cont=$content[0]+1;
			$fp=fopen($file,"w+");
			fwrite($fp,$cont); fclose($fp);
		}else{ $cont=$content[0]; }

		echo "<p>Count: ".$cont."<br/>";
		?>
		</div>
		<?php } ?>

		<br/>
		<?php
		$sections=array("form","page");
		if(isset($_GET['s']) && in_array($_GET['s'],$sections)){
			//echo "section: ".$_GET['s']."<br/>";
			switch(strtolower($_GET['s'])){
				case "form": 
					//catch for the forms....
					$admin_only=array("del_post","edit_post");
					
					include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/formManage.php");
					$file=$_SERVER['DOCUMENT_ROOT']."/diggclone/inc/forms/".$_GET['n'].".php";
					$con_name=$_GET['n'];
					if(is_file($file)){
						include_once($file); $form=new $con_name($digg); //print_r($form);
						if(in_array($_GET['n'],$admin_only)){
							if($digg->user->isLoggedIn() && $digg->user->isAdmin()){ 
								$form->run();
							}else{ echo "You are not allowed to access this resource...<br/>\n"; }
						}else{ $form->run(); } 
					}else{ echo "You have reached an invalid resource....please return to <a href=\"index.php\">the main page</a><br/>\n"; }
					break;
				case "page": 
					include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/inc/pages/".$_GET['n'].".php");
					break;
				default: echo "You have reached an invalid resource!<br/>";
			}
		}else{
			// Display user information....
			if(isset($_GET['user'])){
				$user_info=$digg->user->getUserInfo($_GET['user']); //print_r($user_info);
				echo "<b>User:</b> ".$user_info['username']."<br/><br/>";

				$returned=$digg->getUserPosts($_GET['user']);
				//echo "<pre>"; print_r($returned); echo "</pre>";
				
				echo "<b>Posts made (".count($returned)."):</b><br/>";
				echo "<div style=\"padding:5 0 0 15\">";
				foreach($returned as $key => $value){
					if($value['vote_count']<$digg->promote_level){
						$link="index.php?n=cast_votes&post_id=".$value['ID'];
					}else{ $link="index.php?post_id=".$value['ID']; }
					echo "<a style=\"font-size:12px\" href=\"".$link."\">".$value['title']."</a><br/>\n";
					echo date("m.d.Y H:i:s",$value['date_posted'])." | votes: ".$value['vote_count']."<br/>";
					echo "<br/>";
				}
				echo "</div>";

				$returned=$digg->getUserComments($_GET['user']);
				//echo "<pre>"; print_r($returned); echo "</pre>";
				
				echo "<b>Comments made on (".count($returned)."):</b><br/>";
				echo "<div style=\"padding:5 0 0 15\">";
				foreach($returned as $key => $value){
					echo "<a style=\"font-size:12px\" href=\"\">".$value['title']."</a><br/>";
					echo date("m.d.Y H:i:s",$value['date_posted'])."<br/>";
					echo "<br/>";
				}
				echo "</div>";
				break;
			}
			
			$cast_votes=(strstr($_SERVER['REQUEST_URI'],"n=cast_votes")) ? true : false;
			echo "<a href=\"".$digg->buildFeedURL()."\"><img src=\"img/xml.gif\" border=\"0\"></a><br/><br/>";

			$id=	(isset($_GET['post_id']))	? $_GET['post_id']	: '';
			$page=	(isset($_GET['page']))		? $_GET['page']		: '1';
			$cat=	(isset($_GET['cat_id']))	? $_GET['cat_id']	: '';
			$pro=	($cast_votes)				? '0' : '1';

			if(isset($_GET['search']) && $_GET['search']=="1"){
				$posts=$digg->searchPosts($_POST['search_term']);
			}else{
				$posts_count=count($digg->getStoryData($id,"0",$pro,$cat));
				$posts=$digg->getStoryData($id,$page,$pro,$cat); //echo "<pre>"; print_r($posts); echo "</pre>";
			}

			if(empty($posts)){ 
				echo "No promoted posts found!<br/>"; 
				echo "Looked in <a href=\"".$_SERVER['PHP_SELF']."?&n=cast_votes\">the Voting section</a> yet?";
				break; 
			}

			foreach($posts as $key => $value){
				if($cast_votes || $value['vote_count']<$digg->promote_level){
					$vb_class="vote_block_fade";
					$vb_img="arrow_fade.gif";
					$comment_link=$_SERVER['PHP_SELF']."?n=cast_votes&post_id=".$value['ID'];
					$section_link=$_SERVER['PHP_SELF']."?n=cast_votes&cat_id=".$value['cat_id'];
				}else{
					$vb_class="vote_block";
					$vb_img="arrow.gif";
					$comment_link=$_SERVER['PHP_SELF']."?post_id=".$value['ID'];
					$section_link=$_SERVER['PHP_SELF']."?cat_id=".$value['cat_id'];
				}
				
				if($digg->user->isLoggedIn()){ 
					$link="<a href=\"#\" onClick=\"updateDiv('vote_count_".$value['ID']."','".$digg->user->getUserID()."')\">";
				}else{
					$link="<a href=\"index.php?s=form&n=login\">";
				}

				if($digg->user->isLoggedIn() && $digg->user->isAdmin()){ 
					$admin_links="[<a class=\"admin_link\" href=\"".$_SERVER['PHP_SELF']."?s=form&n=del_post&id=".$value['ID']."\">delete</a>] ";
					$admin_links.="[<a class=\"admin_link\" href=\"".$_SERVER['PHP_SELF']."?s=form&n=edit_post&id=".$value['ID']."\">edit</a>]<br/>";
				}else{ $admin_links=""; }

				echo sprintf('
					<table cellpadding="0" cellpaddding="0" border="0" id="post_table">
					<tr>
						<td class="%s" rowspan="4">
							<span style="font-size:14px;font-weight:bold"><div style="padding:0px;margin:0px" id="vote_count_%s">%s</div></span>votes<br/>
							%s
							<img src="img/%s" border="0"/>
							<br/>
							<span style="font-size:9px">[vote]</span>
							</a>
						</td>
						<td class="title"><a class="title_link" href="%s">%s</a></td>
					</tr>
					<tr><td class="submitted">%ssubmitted by <a href="index.php?user=%s">%s</a> at %s</td></tr>
					<tr><td class="content">%s</td></tr>
					<tr>
						<td>
							<table cellpadding="0" cellspacing="0" border="0" id="post_table_sub">
							<tr>
								<td width="120"><a href="%s">%s comments</a></td>
								<td width="120"><a href="">blog</a></td>
								<td width="120" style="text-align:left;padding-left:40px">category: <a href="%s">%s</a></td>
							</tr>
							</table>
						</td>
					</tr>
					</table>
					<br/>
				',$vb_class,$value['ID'],$value['vote_count'],$link,$vb_img,$value['url'],
				$value['title'],$admin_links,$value['submitted_user_id'],
				$value['username'],date("m.d.Y H:i:s",$value['date_posted']),
				$value['content'],$comment_link,$value['comment_count'],
				$section_link,$value['cat_title']);
			}
			if(isset($_GET['post_id'])){
				echo "Comments:<br/>";
				$comments=$digg->getComments($_GET['post_id']);
				//echo "<pre>"; print_r($comments); echo "</pre>";
	
				foreach($comments as $key => $value){
					echo sprintf('
						<table cellpadding="0" cellspacing="0" border="0" id="comment_table">
						<tr><td class="title">%s</td></tr>
						<tr><td class="content">%s</td></tr>
						<tr><td class="date">posted: %s</td></tr>
						</table>
						<br/>
					',$value['title'],nl2br($value['content']),date("m.d.Y H:i:s",$value['date_posted']));
				}

				include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/libs/formManage.php");
				include_once($_SERVER['DOCUMENT_ROOT']."/diggclone/inc/forms/make_comment.php");
				$form=new make_comment();
				$form->run();

				$results=$digg->getPostVoters($_GET['post_id']);
				echo "<div class=\"users_voted\">";
				echo "<h3 style=\"margin:0px\">Users who voted on this post:</h3>";
				foreach($results as $key => $value){
					echo "<a href=\"".$value['ID']."\">".$value['username']."</a><br/>";
				}
				echo "</div>";
			}
		}

		echo "<hr/>";
		if(!isset($_GET['s']) && !isset($_GET['p'])){
			// create the pagination
			$pages=ceil($posts_count/5);
			echo "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\">\n";
			echo "<tr><td>pages:</td>";
			for($i=1;$i<=$pages;$i++){
				if($cast_votes){
					$link=$_SERVER['PHP_SELF']."?n=cast_votes&page=".$i;
				}else{ $link=$_SERVER['PHP_SELF']."?page=".$i; }
				if(isset($_GET['page'])){ 
					if($i==$_GET['page']){ 
						$class="page_link_block_sel"; 
					}else{ $class="page_link_block"; }
				}else{ if($i=="1"){ $class="page_link_block_sel"; }else{ $class="page_link_block"; } }
				echo "<td><a class=\"page_link\" href=\"".$link."\"><div class=\"".$class."\">".$i."</div></a><td/>";
			}
			echo "</tr>";
			echo "</table>";
		}
		?>
	</td>
</tr>
<tr>
	<td></td><td align="center" style="font-size:10px">diggClone - <a href="mailto:enygma@phpdeveloper.org">enygma@phpdeveloper.org</a></td>
</tr>
</table>
</body>
</html>
