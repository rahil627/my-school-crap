webserver.py is the web server
a#.pl files are the professor's test scripts
a#-test folders are professor's the testing directories

other files
302.conf was used for redirection
test.txt was used during testing

classes used from pythons library
BaseHTTPserver.py - may have been edited
urllib.py
urllib2.py

class found on the internet
daemon.py - runs the server and adds error logging

