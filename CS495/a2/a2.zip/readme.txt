webserver.py is the web server
a#.pl files are the professor's test scripts
a#-test folders are professor's the testing directories

classes used from pythons library
BaseHTTPserver.py - may have edited
urllib.py
urllib2.py

class found on the internet
daemon.py - runs the server and adds error logging

test.txt was used during testing

