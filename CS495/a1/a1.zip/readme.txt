webserver.py is the web server
a#.pl files are the professor's test scripts
a#-test folders are professor's the testing directories