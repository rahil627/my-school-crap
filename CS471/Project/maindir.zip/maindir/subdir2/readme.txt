When running the CS_471_Problem2.cpp file, you must have the data.txt file in the same directory as the .cpp file.
The program was compiled in GNU GCC by codeblocks (IDE).
the program will output statistics on both, the console and output.txt.