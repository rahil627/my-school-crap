//Problem 2 : Project for CS 471
/*
reads the virtual addresses, converts it into page references, and stores it in a queue (PRQ).
1) if the page exists in MM, do nothing
2) if the MM is empty, fill it in!
3) if the MM is full, replace page
*/

#include <iostream>
#include <fstream>
#include <queue>
#include <stack>
#include <vector>
#include <algorithm>

using namespace std;

void LRU(int pageSize, int noOfFrames);

void MRU(int pageSize, int noOfFrames);

void FIFO(int pageSize, int noOfFrames);

void OPT(int pageSize, int noOfFrames);

int main()
{
    ofstream fout;
    fout.open("output.txt",ios::app);
    fout<<"OUTPUT"<<endl;
    fout<<"Page Size     # of Frames     PR Algorithm       Page Faults % "<<endl;
    fout.close();
    cout<<"OUTPUT"<<endl;
    cout<<"Page Size     # of Frames     PR Algorithm       Page Faults % "<<endl;

    LRU(512, 4);
    LRU(512, 8);
    LRU(512, 12);
    LRU(1024, 4);
    LRU(1024, 8);
    LRU(1024, 12);
    LRU(2048, 4);
    LRU(2048, 8);
    LRU(2048, 12);

    MRU(512, 4);
    MRU(512, 8);
    MRU(512, 12);
    MRU(1024, 4);
    MRU(1024, 8);
    MRU(1024, 12);
    MRU(2048, 4);
    MRU(2048, 8);
    MRU(2048, 12);

    FIFO(512, 4);
    FIFO(512, 8);
    FIFO(512, 12);
    FIFO(1024, 4);
    FIFO(1024, 8);
    FIFO(1024, 12);
    FIFO(2048, 4);
    FIFO(2048, 8);
    FIFO(2048, 12);

    OPT(512, 4);
    OPT(512, 8);
    OPT(512, 12);
    OPT(1024, 4);
    OPT(1024, 8);
    OPT(1024, 12);
    OPT(2048, 4);
    OPT(2048, 8);
    OPT(2048, 12);

    system("pause");

    return 0;
}

//*************************************************************************************

void LRU(int pageSize, int noOfFrames)
{
     /*
     LRU
     As the algorithm reads PRQ, it puts the used PR's into a vector (PRV)
     it checks past page references (PRV) from the most recent (PRV.end) to the least recent (PRV.begin)
     if it exists in the MM then found[frame]=true.
     The last page reference that matches MM found is the page to replace (target)
     */

    //INITALIZE
    int MM[noOfFrames];/*[pageSize];*///memory allocated to the process - ex. mem[frame][offset] contains the physical address
    for(int i=0; i < noOfFrames; i++)
    {
        MM[i]=-1;//NULL doesn't work for some reason, so -1 is "empty" because page 0 exists
    }

    //read in virtual addresses
    fstream fin;
    fin.open("data.txt",ios::in);
    if (!fin){cout<<"Could not find file =(\n";}

    queue<int> PRQ;//page reference queue

    int temp;

    while(!fin.eof())
    {
        fin>>temp;
        fin.ignore(100,'\n');
        temp=temp/pageSize;
        PRQ.push(temp);
        if(isdigit(fin.peek())==false)
        {
           fin.ignore(100,'\n');
        }//ignores the last line
    }
    fin.close();

    bool fault;//page fault?
    int noOfPages=PRQ.size();//# of different pages
    double noOfPageFaults=0;
    double noOfReads=PRQ.size();//number of virtual addresses in the file/program reads

    vector<int> PRV;//vector of the used page references
    vector<int>::iterator it;

    int targetValue=69;//page to replace

    bool found[noOfFrames];
    int noOfFound=0;

    bool loop;

    while(PRQ.empty()==false)
    {
        fault=true;//reset

        for(int i=0; i<noOfFrames; i++)//check the MM
        {
            if(PRQ.front()==MM[i]){fault=false;}//if the page exists, no fault
        }

        if(fault==false)
        {
            PRV.push_back(PRQ.front());//1

            PRQ.pop();
            noOfPages--;
        }


        else//if(fault==true)
        {
            //if the frame is empty
            for(int i=0; i<noOfFrames; i++)
            {
                if(MM[i]==-1)
                {
                    noOfPageFaults++;
                    MM[i]=PRQ.front();
                    PRV.push_back(PRQ.front());//2
                    PRQ.pop();
                    i=noOfFrames;//exit loop
                    fault=false;//skip next part
                }
            }

            if(fault==true)
            {
                noOfPageFaults++;

                //the agorithm to find the target
                for(int j=0; j<noOfFrames; j++)found[j]=false;//reset found[]

                loop=true;
                for(it=PRV.end()-1;loop==true;it--)//from the current point to the back
                {
                    for(int i=0; i<noOfFrames; i++)
                    {
                        if(*it==MM[i])//compare each frame to the current page reference
                        {
                            found[i]=true;

                            noOfFound=0;//reset

                            for(int j=0; j<noOfFrames; j++){if(found[j]==true)noOfFound++;}
                            if(noOfFound==noOfFrames)
                            {
                                targetValue=*it;
                                i=noOfFrames;
                                loop=false;
                            }//exit both loops!
                        }
                    }
                }
                //end of algorithm

                /*
                cout<<"here's where the algorithm kicks in!"<<endl;
                cout<<"target page: "<<targetValue<<endl;
                cout<<"replace with: "<<PRQ.front()<<endl;
                */

                //replace target
                for(int i=0; i<noOfFrames; i++)
                {
                    if(MM[i]==targetValue)
                    {
                        MM[i]=PRQ.front();
                        PRV.push_back(PRQ.front());//3
                        PRQ.pop();
                    }
                }
            }
        }
    }
    //display end MM and statistics
    double pageFaultPercentage = (noOfPageFaults/noOfReads)*100;
    if (pageSize == 512 && noOfFrames != 12)
    {
    cout<<pageSize<<"           "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        cout<<pageSize<<"           "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }

    ofstream fout;
    fout.open("output.txt",ios::app);
    if (pageSize == 512 && noOfFrames != 12)
    {
    fout<<pageSize<<"           "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        fout<<pageSize<<"           "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"LRU                "<<pageFaultPercentage<<" %"<<endl;
    }

    fout.close();
}

void MRU(int pageSize, int noOfFrames)
{
/*
    MRU
    As the algorithm reads PRQ, it puts the used PR's into a stack
    therefore the top of the stack is the target for page replacement
    */
    //init
    int MM[noOfFrames];/*[pageSize];*///memory allocated to the process - ex. mem[frame][offset] contains the physical address
    for(int i=0; i<noOfFrames; i++)
    {
        MM[i]=-1;//NULL doesn't work for some reason, so -1 is "empty" because page 0 exists
    }


    //read in virtual addresses
    fstream fin;
    fin.open("data.txt",ios::in);
	if (!fin){cout<<"Could not find file =(\n";}

    queue<int> PRQ;//page reference queue
     int temp;

    while(!fin.eof())
    {
        fin>>temp;
        fin.ignore(100,'\n');
        temp=temp/pageSize;
        PRQ.push(temp);
        if(isdigit(fin.peek())==false)
        {
           fin.ignore(100,'\n');
        }//ignores the last line
    }
    fin.close();

    bool fault;//page fault
    int noOfPages=PRQ.size();
    double noOfPageFaults=0;
    double noOfReads=PRQ.size();//number of virtual addresses in the file/program reads

    stack<int> PRS;//stack of the used page references
    int targetValue;
    int targetIndex;

    while(PRQ.empty()==false)
    {
        fault=true;//reset

        for(int i=0; i < noOfFrames; i++)//check the MM
        {
            if(PRQ.front()==MM[i]){fault=false;}//if the page exists, no fault
        }

        if(fault==false)
        {
            PRS.push(PRQ.front());//1
            PRQ.pop();
            noOfPages--;
        }


        else//fault==true
        {
            //if the frame is empty
            for(int i=0; i < noOfFrames; i++)
            {
                if(MM[i]==-1)
                {
                    noOfPageFaults++;
                    MM[i]=PRQ.front();
                    PRS.push(PRQ.front());//2
                    PRQ.pop();
                    i=noOfFrames;//exit loop
                    fault=false;//skip next part
                }
            }

            if(fault==true)//skip or not?
            {
                noOfPageFaults++;

                targetValue=PRS.top();

                for(int i=0; i < noOfFrames; i++)
                {
                    if(MM[i]==targetValue)
                    {
                        MM[i]=PRQ.front();
                        PRS.push(PRQ.front());//3
                        PRQ.pop();
                    }
                }
            }
        }


    }

    //display end MM and statistics
    /*
    cout<<"\nnumber of pages: "<<noOfPages<<endl;
    cout<<"number of page faults: "<<noOfPageFaults<<endl;
    cout<<"page fault percentage: "<<pageFaultPercentage<<"%"<<endl;
    */
    double pageFaultPercentage = (noOfPageFaults/noOfReads)*100;
       if (pageSize == 512 && noOfFrames != 12)
    {
    cout<<pageSize<<"           "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        cout<<pageSize<<"           "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    ofstream fout;
    fout.open("output.txt",ios::app);
    if (pageSize == 512 && noOfFrames != 12)
    {
    fout<<pageSize<<"           "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        fout<<pageSize<<"           "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"MRU                "<<pageFaultPercentage<<" %"<<endl;
    }
    fout.close();
}

//*************************************************************************************

void FIFO(int pageSize, int noOfFrames)
{

    //init
    int MM[noOfFrames];/*[pageSize];*///memory allocated to the process - ex. mem[frame][offset] contains the physical address
    for(int i=0; i<noOfFrames; i++)
    {
        MM[i]=-1;//NULL doesn't work for some reason, so -1 is "empty" because page 0 exists
    }

    //read in virtual addresses
    fstream fin;
    fin.open("data.txt",ios::in);
	if (!fin){cout<<"Could not find file =(\n";}

    queue<int> PRQ;//page reference queue
    int t;//temp

	while(!fin.eof())
	{
        fin>>t;
        fin.ignore(100,'\n');
        t=t/pageSize;
        PRQ.push(t);
        if(isdigit(fin.peek())==false)
        {
          fin.ignore(100,'\n');
        }//ignores the last line
	}
    fin.close();


    bool fault;//page fault
    int noOfPages=PRQ.size();
    double noOfPageFaults=0;
    double noOfReads=PRQ.size();//number of virtual addresses in the file/program reads

    stack<int> PRS;//stack of the used page references

   while(PRQ.empty()==false)
    {
        for(int i=0; i < noOfFrames; i++)
        {
            fault=true;
            for(int j=0; j < noOfFrames; j++)//check the MM
            {
                if(PRQ.front()==MM[j])
                {
                  fault=false;
                }//if the page exists, no fault
            }

              if(fault==false)
              {
                PRQ.pop();
                noOfPages--;
                i--;
              }//pop & don't move node in MM

            else//fault==true
            {
                noOfPageFaults++;
                MM[i]=PRQ.front();
                PRQ.pop();
            }

            if(PRQ.empty()==true)i=noOfFrames;
        }
    }
     //display end MM and statistics
    //cout<<"\nnumber of pages: "<<noOfPages<<endl;
    //cout<<"number of page faults: "<<noOfPageFaults<<endl;
    //cout<<"page fault percentage: "<<pageFaultPercentage<<"%"<<endl;
    double pageFaultPercentage=(noOfPageFaults/noOfReads)*100;
    if (pageSize == 512 && noOfFrames != 12)
    {
    cout<<pageSize<<"           "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        cout<<pageSize<<"           "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }

    ofstream fout;
    fout.open("output.txt",ios::app);
    if (pageSize == 512 && noOfFrames != 12)
    {
    fout<<pageSize<<"           "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        fout<<pageSize<<"           "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"FIFO               "<<pageFaultPercentage<<" %"<<endl;
    }
    fout.close();
}

void OPT(int pageSize, int noOfFrames)
{
 /*
 OPT
 just look at it as a backwards LRU, or LRU in the future!!!
 first, PRQ has to be changed to a container that can be iterated through such as a list or vector.
 then you can just flip around my LRU algorithm to check from the current point to the frontend of the container
 */
  //INITALIZE
    int MM[noOfFrames];//memory allocated to the process - ex. mem[frame][offset] contains the physical address
    for(int i=0; i < noOfFrames; i++)
    {
        MM[i]=-1;//NULL doesn't work for some reason, so -1 is "empty" because page 0 exists
    }
    queue<int> PRQ;//page reference queue
    vector<int> PRV;//vector of the used page references
    vector<int>::iterator it;
    vector<int> FRV;

    //read in virtual addresses
    fstream fin;
    fin.open("data.txt",ios::in);
    if (!fin){cout<<"Could not find file =(\n";}



    int temp;

    while(!fin.eof())
    {
        fin>>temp;
        fin.ignore(100,'\n');
        temp=temp/pageSize;
        FRV.push_back(temp);
        PRQ.push(temp);
        if(isdigit(fin.peek())==false)
        {
           fin.ignore(100,'\n');
        }//ignores the last line
    }
    fin.close();

    bool fault;//page fault?
    int noOfPages=PRQ.size();//# of different pages
    double noOfPageFaults=0;
    double noOfReads=PRQ.size();//number of virtual addresses in the file/program reads



    int targetValue=69;//page to replace
    //int targetIndex;//frame to replace

    bool found[noOfFrames];
    int noOfFound=0;

    bool loop;

    while(PRQ.empty()==false)
    {
        fault=true;//reset

        for(int i=0; i<noOfFrames; i++)//check the MM
        {
            if(PRQ.front()==MM[i]){fault=false;}//if the page exists, no fault
        }

        if(fault==false)
        {
            PRV.push_back(PRQ.front());//1
            PRQ.pop();
            noOfPages--;
        }


        else//if(fault==true)
        {
            //if the frame is empty
            for(int i=0; i<noOfFrames; i++)
            {
                if(MM[i]==-1)
                {
                    noOfPageFaults++;
                    MM[i]=PRQ.front();
                    PRV.push_back(PRQ.front());//2
                    PRQ.pop();
                    i=noOfFrames;//exit loop
                    fault=false;//skip next part
                }
            }

            if(fault==true)
            {
                noOfPageFaults++;

                //the agorithm to find the target
                for(int j=0; j<noOfFrames; j++)found[j]=false;//reset found[]

                loop=true;
                for(it=FRV.end()-1;loop==true;it--)//from the current point to the front
                {
                    for(int i=0; i < noOfFrames; i++)
                    {
                        if(*it==MM[i])//compare each frame to the current page reference
                        {
                            found[i]=true;

                            noOfFound=0;//reset

                            for(int j=0; j<noOfFrames; j++)
                                {
                                    if(found[j]==true)noOfFound++;
                                }
                            if(noOfFound==noOfFrames)
                            {
                                targetValue=*it;
                                i=noOfFrames;
                                loop=false;
                            }//exit both loops!
                        }
                    }
                }
                //end of algorithm

                /*
                cout<<"here's where the algorithm kicks in!"<<endl;
                cout<<"target page: "<<targetValue<<endl;
                cout<<"replace with: "<<PRQ.front()<<endl;
                */

                //replace target
                for(int i=0; i<noOfFrames; i++)
                {
                    if(MM[i]==targetValue)
                    {
                        MM[i]=PRQ.front();
                        PRV.push_back(PRQ.front());//3
                        PRQ.pop();
                    }
                }
            }
        }
    }

    //display end MM and statistics
    double pageFaultPercentage = (noOfPageFaults/noOfReads)*100;
    if (pageSize == 512 && noOfFrames != 12)
    {
    cout<<pageSize<<"           "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        cout<<pageSize<<"           "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        cout<<pageSize<<"          "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       cout<<pageSize<<"          "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }

    ofstream fout;
    fout.open("output.txt",ios::app);
    if (pageSize == 512 && noOfFrames != 12)
    {
    fout<<pageSize<<"           "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (noOfFrames == 12 && pageSize != 1024 && pageSize != 2048)
    {
        fout<<pageSize<<"           "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames != 12)
    {
        fout<<pageSize<<"          "<<noOfFrames<<"               "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 1024 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    if (pageSize == 2048 && noOfFrames == 12)
    {
       fout<<pageSize<<"          "<<noOfFrames<<"              "<<"OPT                "<<pageFaultPercentage<<" %"<<endl;
    }
    fout.close();
}

