#include <sstream>
#include <cmath>
#include <cstdlib>

#include "common.h"
#include "random.cpp"

using namespace std;

record::record(int store) {
  random * rand = new random;
  stringstream out[2];
  int tempRand[2];
  tempRand[0] = (int)rand->getRandom(0)%12;
  tempRand[1] = (int)rand->getRandom(1)%30;
  if(tempRand[0]==0) tempRand[0]=12;
  if(tempRand[1]==0) tempRand[1]=12;

  out[0] << tempRand[0];
  out[1] << tempRand[1];

  storeID = store;
  registerNum = (int)rand->getRandom(4)%10;
  saleDate[0] = out[0].str();
  saleDate[1] = out[1].str();
  saleDate[2] = "06";
  //saleAmount = fabs((float)((int)rand->getRandom(3)%1000-(4000/rand->getRandom(4)), 2));
  saleAmount = fabs(rand->round((float)((int)rand->getRandom(6)%1000-(4000/rand->getRandom(9))), 2));
  next = NULL;
}

int record::getMonth(){
  string temp = saleDate[0];

  return atoi(temp.c_str());
}

record::record() {
  storeID = 0;
  registerNum = 0;
  saleDate[0] = "00";
  saleDate[1] = "00";
  saleDate[2] = "06";
  saleAmount = 0;
  next = NULL;
}
