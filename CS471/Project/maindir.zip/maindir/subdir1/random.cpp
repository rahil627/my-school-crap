#include "random.h"

random::random() {
  srand(GetTickCount());

  for (int i=0; i<20; i++) {  //Used to sleep every other one to ensure unique random numbers
      if (i%2 == 0) {
        n[i/2] = (float)rand();
        Sleep(2);
      }
  }
}

float random::round(float num, int dec) {  //Rewritten to enable the proper rounding of floats
  float done = (num*powf(10.0f, (float)(dec + 1)));
  float done2;

  if (num < 0.0f)
    done -= 5.0f;
  else
    done += 5.0f;

  done /= 10.0f;

  modff(done, &done2);

  return done2/powf(10.0f, (float)dec);
}
