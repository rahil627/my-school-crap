When running the VMEMMAN.cpp file, you must have the input.txt file in the same directory as the .cpp file.
The VMEMMAN.cpp opens the input.txt file to get the addresses for the page algorithms.
Other than that, just run the VMEMMAN.cpp file in Dev C++ or CodeBlocks or some other C++ compiler that uses GNU GCC like 
CodeBlocks, to see the results of the page algorithms and their 9 runs.
After the runing of the VMEMMAN.cpp once, there will be a output.txt file created with all of the data, also the output 
screen will show all the 9 runs.
