#include <iostream>
#include <cstdlib>
#include <windows.h>

int numProducers = 5;
int numConsumers = 2;
const int maxSales = 500;
int totalSales = 0;   //Number of total sales made
int currentSales = 0; //Number of sales left to be consumed

float allSales = 0.0f;   //float of all sales made
float monthSales[12]; //all sales made by month

struct store{
  int storeSaleID;
  float storeSales2;
  store * next;
} *storeSales;

HANDLE aSemaphore;
CRITICAL_SECTION mutex;

class record {
public:
  record(int store);
  record();

  void makeSale(int amt) {saleAmount += amt;}
  void setNext(record * n) {next = n;}

  std::string getDate() {return saleDate[0] + "/" + saleDate[1] + "/" + saleDate[2];}

  int getStoreID() {return storeID;}
  int getRegisterNum() {return registerNum;}
  int getMonth();

  float getSaleAmount() {return saleAmount;}

  record * getNext() {return next;}

private:
  int storeID;
  int registerNum;
  std::string saleDate[3];
  float saleAmount;
  record * next;
};

record * head;
