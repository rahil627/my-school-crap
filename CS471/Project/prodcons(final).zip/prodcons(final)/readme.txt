Quick Guide to Prodcons
-----------------------------
Files
Requirements
FYI

Files
-----------------------------
  There are 5 main files required to run this program; main.cpp, common.h, 
common.cpp, random.h, and random.cpp. The number of max sales to make is located 
in the common.h file, it is currently set to 10,000 like the project requires 
but can be made less to allow for quicker execution time.

Requirements
-----------------------------
This program will NOT currently execute in UNIX and thus must be executed in 
windows. I compiled using Code::Blocks 8.04 but im sure any other similar 
windows compiler would work as well. Because the number of lines randomized is 
so high it takes a long time to execute so a fast processor is desirable.

FYI
-----------------------------
The execution time required of this program is very high, the first execution of 
2 producers and 2 consumers takes a little over 20 minutes to finish the first 
of the 9 runs. Results are output to a file called test.txt, if this file 
already exist within the scope of the executible then the file will be 
appended to and you will have to sift through the data. Thus it is recomended 
that if the file is executed more than once to make sure to delete the test.txt 
file before continuing. 

To change the 10,000 lines to a less amount so you can run the program in a time 
less than 3 hours, change the variable maxsales, in common.h at the top, from 
10,000 to something like 500.

The code can also be optimized to create multiple threads on multicore systems. 
Line 144 in main.cpp, the last 0 before the NULL can be set to the number of 
cores you are running to increase the speed of the program. Example, in the open 
OR lab when running quad cores I changed the variable to 3 to increase the 
execution speed.
