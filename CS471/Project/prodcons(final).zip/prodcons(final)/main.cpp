#include <iostream>
#include <fstream>
#include <iomanip>
#include <ctime>

#include "common.cpp"

using namespace std;

DWORD WINAPI makeSales(int * num) { //Function to create producers
  srand(GetTickCount()); //Sets the seed to the very minute clock tick

  if (totalSales < maxSales) { //If the max ammount of producers has not been reached
    EnterCriticalSection(&mutex); //If another thread is currently in critical section it will wait here until it becomes available

    if (head == NULL) { //If this is the first producer in the list
      head = new record((*num));
      totalSales++;
      currentSales++;
    }
    else {  //If this is not the first producer in the list
      record * temp;
      for (temp = head; temp->getNext()!=NULL; temp=temp->getNext());
      record * hold = new record((*num));
      temp->setNext(hold);
      totalSales++;
      currentSales++;
    }
    LeaveCriticalSection(&mutex); //Leaves critical section to allow another thread in
  }
  else  //If the max amount of producers has been reached
    return true;

  Sleep(rand()%(36)+5); //specific requirement to sleep from 5ms to 40ms
  return true;
}

DWORD WINAPI saleStuff() { //Function to create consumers
  if (currentSales > 0) { //If there are any sales to be consumed
    EnterCriticalSection(&mutex); //If another thread is currently in critical section it will wait here until it becomes available

    record * temp;
    temp = head;

    int month = temp->getMonth();
    int storeID = temp->getStoreID();
    float price = temp->getSaleAmount();
    bool found = false;

    allSales += price;

    if(storeSales==NULL){
      storeSales = new store;
      storeSales->storeSaleID=storeID;
      storeSales->storeSales2=price;
      storeSales->next=NULL;
      found = true;
    }
    else{
      for(store * temp=storeSales;temp->next!=NULL;temp=temp->next){
        if (temp->storeSaleID==storeID){
          temp->storeSales2+=price;
          found=true;
        }
      }
    }

    if (!found) {
      store * temp;
      for (temp = storeSales; temp->next!=NULL; temp=temp->next);
      store * hold = new store;
      hold->storeSaleID=storeID;
      hold->storeSales2=price;
      temp->next = hold;
      hold->next = NULL;
    }

    monthSales[month-1] += price;

    temp = temp->getNext();
    head = temp;
    currentSales--;

    LeaveCriticalSection(&mutex); //Leaves critical section to allow another thread in
  }
  else  //If the max amount of producers has been reached
    return true;

  return true;
}

int main() {
  int start;

  HANDLE producers[numProducers]; //Producers
  HANDLE consumers[numConsumers]; //Consumers

  int pids[numProducers]; //Array of unique thread ids
  int pids2[numConsumers];

  ofstream myOut;

  InitializeCriticalSectionAndSpinCount(&mutex, 0); //Initalizes the mutex so it can be used

  for (int numRuns=0; numRuns<9; numRuns++) {
    switch(numRuns) {
        case 0: numProducers = 2;
                numConsumers = 2;
                break;
        case 1: numProducers = 2;
                numConsumers = 5;
                break;
        case 2: numProducers = 2;
                numConsumers = 10;
                break;
        case 3: numProducers = 5;
                numConsumers = 2;
                break;
        case 4: numProducers = 5;
                numConsumers = 5;
                break;
        case 5: numProducers = 5;
                numConsumers = 10;
                break;
        case 6: numProducers = 10;
                numConsumers = 2;
                break;
        case 7: numProducers = 10;
                numConsumers = 5;
                break;
        case 8: numProducers = 10;
                numConsumers = 10;
                break;
        default: break;
    }

      start = clock(); //Begins the clock to keep track of execution time

      for (int i=0; i<12; i++) //initalizes month and store total sales
        monthSales[i]=0.0f;

       while (totalSales < maxSales) {  //Loop for Producing
        for (int temp=0; temp<numProducers; temp++) {
          producers[temp] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)makeSales, &pids[temp], 0, NULL); //Creates a new producer thread (can be optimized to run on a multicore sytem)
          pids[temp] = temp; //Records the new producers id

          SetThreadPriority(producers[temp], THREAD_PRIORITY_NORMAL);
        }
        WaitForMultipleObjects(numProducers, producers, TRUE, INFINITE); //Waits for all the threads to finish before continuing
        for (int i=0; i<numProducers; i++) {
          CloseHandle(producers[i]); //Closes all the threads for producers
        }
      }

      if (!ifstream("test.txt")) {
        myOut.open("test.txt", ios::out);
        myOut.close();
      }

      myOut.open("test.txt",ios::app);

      myOut << "Number Producers: " << numProducers << endl;
      myOut << "Number Consumers: " << numConsumers << endl;
      myOut << "-------------------------------------------" << endl;

      for (record * temp = head; temp != NULL; temp=temp->getNext()) //Prints all the data to file because its quicker and easier to read
        myOut << fixed << setprecision(2) << "$" << temp->getSaleAmount() << ", Store: " << temp->getStoreID()+1 << ", Date: " << temp->getDate() << ", Register: " << temp->getRegisterNum()+1 << endl;

      while (currentSales > 0) {  //Loop for Consuming
        for (int temp=0; temp<numConsumers; temp++) {
          consumers[temp] = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)saleStuff, &pids2[temp], 0, NULL); //Creates a new consumer thread
          pids2[temp] = temp; //Records the new consumers id

          SetThreadPriority(consumers[temp], THREAD_PRIORITY_NORMAL);
        }
        WaitForMultipleObjects(numConsumers, producers, TRUE, INFINITE); //Waits for all the threads to finish before continuing
        for (int i=0; i<numConsumers; i++) {
          CloseHandle(consumers[i]); //Closes all the threads for producers
        }
      }

      myOut << endl;
      for (store * temp=storeSales; temp->next!=NULL; temp=temp->next)
        myOut << "Store " << temp->storeSaleID+1 << " sales: $" << temp->storeSales2 << endl;

      for (int i=0; i<12; i++)
        myOut << "Month " << i+1 << " sales: $" << monthSales[i] << endl;

      myOut << "Aggregate Sales: $" << allSales << endl;

      myOut << "Elapsed time: " << (clock() - start) << "ms" << endl << endl;

      myOut.close();

      cout << endl << "Elapsed time: " << (clock() - start) << "ms" << endl;

      store * temp = storeSales; //Cleanup of store sales records
      while (temp != NULL) {
        store * next = temp->next;
        delete temp;
        temp = next;
      }
      storeSales = NULL;
      record * temp2 = head; //Cleanup of randomized records
      while (temp2 != NULL) {
        record * next = temp2->getNext();
        delete temp2;
        temp2 = next;
      }
      head = NULL;
      totalSales = 0;
      currentSales = 0;
      allSales = 0.0f;

  }

  DeleteCriticalSection(&mutex); //Cleanup of mutex

  return 0;
}
