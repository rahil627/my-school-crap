#include <cstdlib>
#include <iostream>
#include <cmath>

class random {
  public:
    random();
    float getRandom(int i) {return n[i];}
    float round(float num, int dec);

  private:
    float n[10];
};
