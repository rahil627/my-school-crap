/* If you compile the code, you quickly discover the names of the missing
   functions: addStaff, numberOfStaff, and operator< 

   Part 1 of the assignment is to supply those, and none of
   them are particularly complicated */