package PipeLayer;

public interface Scored 
{
  public void computeScore();
}
