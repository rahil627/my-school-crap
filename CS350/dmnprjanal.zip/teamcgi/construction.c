/* construction.cgi.c - Page Under Construction CGI */

#include <stdio.h>

int main() {
   printf("Content-Type: text/html\r\n\r\n");
   printf("<html> <head>\n");
   printf("<title>Sorry! This page is under construction</title>\n");
   printf("</head>\n");
   printf("<body>\n");
   printf("<h1>Sorry!<br> This page is under construction.</h1>\n");
   printf("</body> </html>\n");
}
