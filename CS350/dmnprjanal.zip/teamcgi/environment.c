/* env.cgi.c */

#include <stdio.h>

extern char **environ;

int main()
{
   char **p = environ;

   printf("Content-Type: text/html\r\n\r\n");
   printf("<html> <head>\n");
   printf("<title>CGI Environment</title>\n");
   printf("</head>\n");
   printf("<body>\n");
   printf("<h1>CGI Environment</h1>\n");

   while(*p != NULL)
      printf("%s<br>\n",*p++);

   printf("</body> </html>\n");
}
