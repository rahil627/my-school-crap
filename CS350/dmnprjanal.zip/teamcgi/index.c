#include <stdio.h>

int main()
{
  printf("Location: /index.html\r\n\r\n");
}
