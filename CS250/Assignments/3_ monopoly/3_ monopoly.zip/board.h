class board
{
private:
	//board*squares;
	//squares=new board[40];
	
	//using arrays
	//property specialSquare[12];
	//residential residentialSquare[22]
	//railroad railroadSquare[4]
	//utility utilitySquare[2]


public:
	void construct()
	{;
//		for(int i=0;i<40;i++){square[i]=i;}
	}
	void display()
	{;
//		for(int i=0;i<40;i++){cout<<square[i]<<endl;}
	}
};