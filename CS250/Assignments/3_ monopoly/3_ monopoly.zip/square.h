class bones
{
private:

public:

};